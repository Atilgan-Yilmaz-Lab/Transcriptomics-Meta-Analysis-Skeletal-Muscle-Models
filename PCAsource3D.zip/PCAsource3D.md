PCA of all samples (source and interest) including 115 new samples (first I check their clustering and behaviour and then do full PCA - 3D added to this one


```R
setwd("/staging/leuven/stg_00134/GENERAL/rawdata/STARoutput/Ranalysis/")
```


```R
#Libraries
library(tximport)
library(tidyr)
library(magrittr)
library(ggplot2)
library(readr)
library(dplyr)
library(tibble)
library(edgeR)
library(ensembldb)
library(rhdf5)
library(beepr)
library(EnsDb.Hsapiens.v86)
library(readr)
library(plotly)
library(limma)
library(gt)
library(DT)
library("VennDiagram")
library(tidyverse)
library(limma)
library(RColorBrewer)
library(gplots)
library(heatmaply) 
library(d3heatmap)
```

    
    Attaching package: ‘magrittr’
    
    
    The following object is masked from ‘package:tidyr’:
    
        extract
    
    
    
    Attaching package: ‘dplyr’
    
    
    The following objects are masked from ‘package:stats’:
    
        filter, lag
    
    
    The following objects are masked from ‘package:base’:
    
        intersect, setdiff, setequal, union
    
    
    Loading required package: limma
    
    Loading required package: BiocGenerics
    
    
    Attaching package: ‘BiocGenerics’
    
    
    The following object is masked from ‘package:limma’:
    
        plotMA
    
    
    The following objects are masked from ‘package:dplyr’:
    
        combine, intersect, setdiff, union
    
    
    The following objects are masked from ‘package:stats’:
    
        IQR, mad, sd, var, xtabs
    
    
    The following objects are masked from ‘package:base’:
    
        anyDuplicated, aperm, append, as.data.frame, basename, cbind,
        colnames, dirname, do.call, duplicated, eval, evalq, Filter, Find,
        get, grep, grepl, intersect, is.unsorted, lapply, Map, mapply,
        match, mget, order, paste, pmax, pmax.int, pmin, pmin.int,
        Position, rank, rbind, Reduce, rownames, sapply, setdiff, sort,
        table, tapply, union, unique, unsplit, which.max, which.min
    
    
    Loading required package: GenomicRanges
    
    Loading required package: stats4
    
    Loading required package: S4Vectors
    
    
    Attaching package: ‘S4Vectors’
    
    
    The following objects are masked from ‘package:dplyr’:
    
        first, rename
    
    
    The following object is masked from ‘package:tidyr’:
    
        expand
    
    
    The following object is masked from ‘package:utils’:
    
        findMatches
    
    
    The following objects are masked from ‘package:base’:
    
        expand.grid, I, unname
    
    
    Loading required package: IRanges
    
    
    Attaching package: ‘IRanges’
    
    
    The following objects are masked from ‘package:dplyr’:
    
        collapse, desc, slice
    
    
    Loading required package: GenomeInfoDb
    
    
    Attaching package: ‘GenomicRanges’
    
    
    The following object is masked from ‘package:magrittr’:
    
        subtract
    
    
    Loading required package: GenomicFeatures
    
    Loading required package: AnnotationDbi
    
    Loading required package: Biobase
    
    Welcome to Bioconductor
    
        Vignettes contain introductory material; view with
        'browseVignettes()'. To cite Bioconductor, see
        'citation("Biobase")', and for packages 'citation("pkgname")'.
    
    
    
    Attaching package: ‘AnnotationDbi’
    
    
    The following object is masked from ‘package:dplyr’:
    
        select
    
    
    Loading required package: AnnotationFilter
    
    
    Attaching package: ‘AnnotationFilter’
    
    
    The following object is masked from ‘package:magrittr’:
    
        not
    
    
    
    Attaching package: 'ensembldb'
    
    
    The following object is masked from 'package:dplyr':
    
        filter
    
    
    The following object is masked from 'package:stats':
    
        filter
    
    
    
    Attaching package: 'plotly'
    
    
    The following objects are masked from 'package:ensembldb':
    
        filter, select
    
    
    The following object is masked from 'package:AnnotationDbi':
    
        select
    
    
    The following object is masked from 'package:IRanges':
    
        slice
    
    
    The following object is masked from 'package:S4Vectors':
    
        rename
    
    
    The following object is masked from 'package:ggplot2':
    
        last_plot
    
    
    The following object is masked from 'package:stats':
    
        filter
    
    
    The following object is masked from 'package:graphics':
    
        layout
    
    
    Loading required package: grid
    
    Loading required package: futile.logger
    
    ── [1mAttaching core tidyverse packages[22m ──────────────────────── tidyverse 2.0.0 ──
    [32m✔[39m [34mforcats  [39m 1.0.0     [32m✔[39m [34mpurrr    [39m 1.0.2
    [32m✔[39m [34mlubridate[39m 1.9.3     [32m✔[39m [34mstringr  [39m 1.5.0
    ── [1mConflicts[22m ────────────────────────────────────────── tidyverse_conflicts() ──
    [31m✖[39m [34mlubridate[39m::[32m%within%()[39m     masks [34mIRanges[39m::%within%()
    [31m✖[39m [34mIRanges[39m::[32mcollapse()[39m       masks [34mdplyr[39m::collapse()
    [31m✖[39m [34mBiobase[39m::[32mcombine()[39m        masks [34mBiocGenerics[39m::combine(), [34mdplyr[39m::combine()
    [31m✖[39m [34mIRanges[39m::[32mdesc()[39m           masks [34mdplyr[39m::desc()
    [31m✖[39m [34mS4Vectors[39m::[32mexpand()[39m       masks [34mtidyr[39m::expand()
    [31m✖[39m [34mmagrittr[39m::[32mextract()[39m       masks [34mtidyr[39m::extract()
    [31m✖[39m [34mplotly[39m::[32mfilter()[39m          masks [34mensembldb[39m::filter(), [34mdplyr[39m::filter(), [34mstats[39m::filter()
    [31m✖[39m [34mS4Vectors[39m::[32mfirst()[39m        masks [34mdplyr[39m::first()
    [31m✖[39m [34mdplyr[39m::[32mlag()[39m              masks [34mstats[39m::lag()
    [31m✖[39m [34mAnnotationFilter[39m::[32mnot()[39m   masks [34mmagrittr[39m::not()
    [31m✖[39m [34mBiocGenerics[39m::[32mPosition()[39m  masks [34mggplot2[39m::Position(), [34mbase[39m::Position()
    [31m✖[39m [34mpurrr[39m::[32mreduce()[39m           masks [34mGenomicRanges[39m::reduce(), [34mIRanges[39m::reduce()
    [31m✖[39m [34mplotly[39m::[32mrename()[39m          masks [34mS4Vectors[39m::rename(), [34mdplyr[39m::rename()
    [31m✖[39m [34mlubridate[39m::[32msecond()[39m       masks [34mS4Vectors[39m::second()
    [31m✖[39m [34mlubridate[39m::[32msecond<-()[39m     masks [34mS4Vectors[39m::second<-()
    [31m✖[39m [34mplotly[39m::[32mselect()[39m          masks [34mensembldb[39m::select(), [34mAnnotationDbi[39m::select(), [34mdplyr[39m::select()
    [31m✖[39m [34mpurrr[39m::[32mset_names()[39m        masks [34mmagrittr[39m::set_names()
    [31m✖[39m [34mplotly[39m::[32mslice()[39m           masks [34mIRanges[39m::slice(), [34mdplyr[39m::slice()
    [31m✖[39m [34mGenomicRanges[39m::[32msubtract()[39m masks [34mmagrittr[39m::subtract()
    [36mℹ[39m Use the conflicted package ([3m[34m<http://conflicted.r-lib.org/>[39m[23m) to force all conflicts to become errors
    
    Attaching package: 'gplots'
    
    
    The following object is masked from 'package:IRanges':
    
        space
    
    
    The following object is masked from 'package:S4Vectors':
    
        space
    
    
    The following object is masked from 'package:stats':
    
        lowess
    
    
    Loading required package: viridis
    
    Loading required package: viridisLite
    
    
    ======================
    Welcome to heatmaply version 1.5.0
    
    Type citation('heatmaply') for how to cite the package.
    Type ?heatmaply for the main documentation.
    
    The github page is: https://github.com/talgalili/heatmaply/
    Please submit your suggestions and bug-reports at: https://github.com/talgalili/heatmaply/issues
    You may ask questions at stackoverflow, use the r and heatmaply tags: 
    	 https://stackoverflow.com/questions/tagged/heatmaply
    ======================
    
    
    
    Attaching package: 'heatmaply'
    
    
    The following object is masked from 'package:BiocGenerics':
    
        normalize
    
    



```R
counts = "/staging/leuven/stg_00134/GENERAL/rawdata/STARoutput/Ranalysis/Comparisons/allFC.counts.NOV.tsv"
counts <- as.matrix(read.csv(counts, sep="\t", row.names="X"))
colnames(counts) <- sub("^X", "", colnames(counts)) #to remove the Xs in the column names (this happens bc the column names start with a number)
dim(counts)
head(counts)
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>61228</li><li>540</li></ol>




<table class="dataframe">
<caption>A matrix: 6 × 540 of type int</caption>
<thead>
	<tr><th></th><th scope=col>1D_hPSC1</th><th scope=col>1D_hPSC2</th><th scope=col>1D_hPSC3</th><th scope=col>1D_hPSC4</th><th scope=col>1D_MB1</th><th scope=col>1D_MB2</th><th scope=col>1D_MB3</th><th scope=col>1D_MB4</th><th scope=col>1D_MP1</th><th scope=col>1D_MP2</th><th scope=col>⋯</th><th scope=col>62F_FSM7</th><th scope=col>62F_FSM8</th><th scope=col>62F_FSM9</th><th scope=col>63_3D_04w_01</th><th scope=col>63_3D_04w_02</th><th scope=col>63_3D_04w_03</th><th scope=col>63_3D_08w_01</th><th scope=col>63_3D_08w_02</th><th scope=col>63_3D_16w_01</th><th scope=col>63_3D_16w_02</th></tr>
</thead>
<tbody>
	<tr><th scope=row>5_8S_rRNA</th><td> 0</td><td> 0</td><td> 0</td><td> 0</td><td> 1</td><td> 1</td><td> 0</td><td> 4</td><td> 0</td><td> 0</td><td>⋯</td><td> 1</td><td> 0</td><td> 0</td><td> 0</td><td> 0</td><td> 0</td><td>  0</td><td> 0</td><td>33</td><td>25</td></tr>
	<tr><th scope=row>5S_rRNA</th><td> 8</td><td> 0</td><td> 6</td><td> 8</td><td> 4</td><td> 1</td><td> 4</td><td> 2</td><td> 1</td><td> 3</td><td>⋯</td><td> 1</td><td> 0</td><td> 2</td><td> 3</td><td> 0</td><td> 1</td><td>  0</td><td> 0</td><td> 4</td><td> 6</td></tr>
	<tr><th scope=row>7SK</th><td>14</td><td> 6</td><td> 9</td><td> 5</td><td> 9</td><td> 4</td><td>20</td><td>12</td><td>10</td><td>15</td><td>⋯</td><td> 0</td><td> 1</td><td> 0</td><td>13</td><td>15</td><td>22</td><td> 21</td><td> 2</td><td> 0</td><td> 2</td></tr>
	<tr><th scope=row>A1BG</th><td>11</td><td> 5</td><td> 9</td><td> 2</td><td>18</td><td> 6</td><td>42</td><td>18</td><td>15</td><td>22</td><td>⋯</td><td> 5</td><td> 2</td><td> 7</td><td>16</td><td>23</td><td>23</td><td> 26</td><td>32</td><td>10</td><td>11</td></tr>
	<tr><th scope=row>A1BG-AS1</th><td>28</td><td>21</td><td>46</td><td>42</td><td>56</td><td>41</td><td>76</td><td>43</td><td>43</td><td>47</td><td>⋯</td><td>30</td><td>35</td><td>18</td><td>54</td><td>56</td><td>38</td><td>127</td><td>64</td><td>12</td><td>16</td></tr>
	<tr><th scope=row>A1CF</th><td> 9</td><td> 8</td><td>13</td><td> 9</td><td>23</td><td>24</td><td>52</td><td>32</td><td>10</td><td>11</td><td>⋯</td><td> 7</td><td>20</td><td> 2</td><td> 2</td><td> 0</td><td> 0</td><td>  4</td><td> 7</td><td> 1</td><td> 2</td></tr>
</tbody>
</table>




```R
counts <- as.data.frame(counts)
```

# PCA of all samples 


```R
MT1 <- dplyr::select(counts, contains(c("Gene_ID","1D_MP","9D_MP","10D_MP","12D_MP_L9","12D_MP_L10","12D_MP_L11","12D_MP_L12","13D_MP","17D_MP","15D_MP","6D_MP13","6D_MP14","6D_MP15","6D_MP16","6D_MP17","6D_MP18","12D_MP_L13","12D_MP_L14","12D_MB_L1","12D_MB_L2","12D_MB_S1","D_MT","T_MP","T_MB","T_MT","E_MP","10F_FSM","13F_MP","33A","13A","20A_MB","46A_MB","47A_MB","49A_MB","50A_MB","52A_MB","54A_MB","60A_MB","43C_MB","39C","41C","45C","53C","24A_MB","55C","58C","47A","40C_MT","hPSC","T_FB","34A_T1","34A_T2", "61A", "62F", "63_3D")))
MT1
```


<table class="dataframe">
<caption>A data.frame: 61228 × 418</caption>
<thead>
	<tr><th></th><th scope=col>1D_MP1</th><th scope=col>1D_MP2</th><th scope=col>1D_MP3</th><th scope=col>1D_MP4</th><th scope=col>9D_MP1</th><th scope=col>9D_MP2</th><th scope=col>9D_MP3</th><th scope=col>9D_MP4</th><th scope=col>10D_MP1</th><th scope=col>10D_MP2</th><th scope=col>⋯</th><th scope=col>62F_FSM7</th><th scope=col>62F_FSM8</th><th scope=col>62F_FSM9</th><th scope=col>63_3D_04w_01</th><th scope=col>63_3D_04w_02</th><th scope=col>63_3D_04w_03</th><th scope=col>63_3D_08w_01</th><th scope=col>63_3D_08w_02</th><th scope=col>63_3D_16w_01</th><th scope=col>63_3D_16w_02</th></tr>
	<tr><th></th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>⋯</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>5_8S_rRNA</th><td>  0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>⋯</td><td>    1</td><td>    0</td><td>    0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>  33</td><td>  25</td></tr>
	<tr><th scope=row>5S_rRNA</th><td>  1</td><td>   3</td><td>   9</td><td>   5</td><td>   1</td><td>   0</td><td>   0</td><td>   1</td><td>   0</td><td>   0</td><td>⋯</td><td>    1</td><td>    0</td><td>    2</td><td>   3</td><td>   0</td><td>   1</td><td>   0</td><td>   0</td><td>   4</td><td>   6</td></tr>
	<tr><th scope=row>7SK</th><td> 10</td><td>  15</td><td>   8</td><td>  13</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>⋯</td><td>    0</td><td>    1</td><td>    0</td><td>  13</td><td>  15</td><td>  22</td><td>  21</td><td>   2</td><td>   0</td><td>   2</td></tr>
	<tr><th scope=row>A1BG</th><td> 15</td><td>  22</td><td>  23</td><td>  23</td><td>  10</td><td>   4</td><td>   4</td><td>   3</td><td>   3</td><td>   2</td><td>⋯</td><td>    5</td><td>    2</td><td>    7</td><td>  16</td><td>  23</td><td>  23</td><td>  26</td><td>  32</td><td>  10</td><td>  11</td></tr>
	<tr><th scope=row>A1BG-AS1</th><td> 43</td><td>  47</td><td>  59</td><td>  87</td><td>  44</td><td>  50</td><td>  54</td><td>  51</td><td>  29</td><td>  42</td><td>⋯</td><td>   30</td><td>   35</td><td>   18</td><td>  54</td><td>  56</td><td>  38</td><td> 127</td><td>  64</td><td>  12</td><td>  16</td></tr>
	<tr><th scope=row>A1CF</th><td> 10</td><td>  11</td><td>  22</td><td>  24</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   1</td><td>⋯</td><td>    7</td><td>   20</td><td>    2</td><td>   2</td><td>   0</td><td>   0</td><td>   4</td><td>   7</td><td>   1</td><td>   2</td></tr>
	<tr><th scope=row>A2M</th><td>122</td><td> 135</td><td> 237</td><td> 323</td><td> 442</td><td> 451</td><td> 371</td><td> 366</td><td>  31</td><td>3338</td><td>⋯</td><td>37580</td><td>26320</td><td>20334</td><td>  27</td><td>  20</td><td>  23</td><td>2156</td><td>1021</td><td>1055</td><td>2552</td></tr>
	<tr><th scope=row>A2M-AS1</th><td> 55</td><td>  53</td><td>  94</td><td>  97</td><td>  41</td><td>  39</td><td>  37</td><td>  27</td><td>   8</td><td>  91</td><td>⋯</td><td>  147</td><td>   81</td><td>   78</td><td>  63</td><td>  77</td><td>  56</td><td> 110</td><td>  62</td><td>   8</td><td>  23</td></tr>
	<tr><th scope=row>A2ML1</th><td>  1</td><td>   3</td><td>   8</td><td>  14</td><td>   1</td><td>   1</td><td>   0</td><td>   0</td><td>   1</td><td>   0</td><td>⋯</td><td>    3</td><td>    1</td><td>   66</td><td>   4</td><td>   3</td><td>   1</td><td>   7</td><td>   1</td><td>   1</td><td>   1</td></tr>
	<tr><th scope=row>A2ML1-AS1</th><td>  0</td><td>   0</td><td>   1</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   1</td><td>⋯</td><td>    0</td><td>    0</td><td>    0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td></tr>
	<tr><th scope=row>A2ML1-AS2</th><td>  0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>⋯</td><td>    0</td><td>    0</td><td>    0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td></tr>
	<tr><th scope=row>A2MP1</th><td>  6</td><td>   9</td><td>  13</td><td>  12</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>⋯</td><td>   11</td><td>   16</td><td>   10</td><td>   3</td><td>   5</td><td>   7</td><td>   9</td><td>   1</td><td>   2</td><td>   1</td></tr>
	<tr><th scope=row>A3GALT2</th><td>  5</td><td>   4</td><td>   6</td><td>   3</td><td>   1</td><td>   1</td><td>   4</td><td>   1</td><td>   0</td><td>   0</td><td>⋯</td><td>    1</td><td>    4</td><td>    0</td><td>   1</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td></tr>
	<tr><th scope=row>A4GALT</th><td>  7</td><td>  11</td><td>   6</td><td>  30</td><td> 174</td><td> 214</td><td> 417</td><td> 336</td><td> 142</td><td> 125</td><td>⋯</td><td> 1145</td><td> 1114</td><td>  935</td><td>   4</td><td>   2</td><td>   5</td><td> 242</td><td> 158</td><td>  39</td><td>  59</td></tr>
	<tr><th scope=row>A4GNT</th><td>  0</td><td>   1</td><td>   1</td><td>   3</td><td>   0</td><td>   1</td><td>   4</td><td>   2</td><td>   0</td><td>   0</td><td>⋯</td><td>    1</td><td>    0</td><td>    2</td><td>   0</td><td>   0</td><td>   0</td><td>   2</td><td>   0</td><td>   2</td><td>   0</td></tr>
	<tr><th scope=row>AA06</th><td>  0</td><td>   0</td><td>   1</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>⋯</td><td>    0</td><td>    0</td><td>    0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td></tr>
	<tr><th scope=row>AAAS</th><td>629</td><td> 628</td><td>1021</td><td>1854</td><td>1132</td><td> 999</td><td>1104</td><td>1118</td><td>1007</td><td>1021</td><td>⋯</td><td> 2164</td><td> 1701</td><td> 1577</td><td> 635</td><td> 693</td><td> 622</td><td>1495</td><td>1053</td><td> 109</td><td> 145</td></tr>
	<tr><th scope=row>AACS</th><td>363</td><td> 397</td><td> 612</td><td> 673</td><td> 514</td><td> 543</td><td> 504</td><td> 554</td><td> 588</td><td> 719</td><td>⋯</td><td> 2148</td><td> 1875</td><td> 2276</td><td> 358</td><td> 436</td><td> 379</td><td>2015</td><td>1139</td><td> 134</td><td> 197</td></tr>
	<tr><th scope=row>AACSP1</th><td> 33</td><td>  20</td><td>   3</td><td>  29</td><td>   1</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   2</td><td>⋯</td><td>    2</td><td>    5</td><td>    6</td><td>   1</td><td>   2</td><td>   3</td><td>   5</td><td>   3</td><td>   0</td><td>   2</td></tr>
	<tr><th scope=row>AADAC</th><td>  0</td><td>   0</td><td>   0</td><td>   0</td><td>   2</td><td>   2</td><td>   3</td><td>   6</td><td>  15</td><td>   0</td><td>⋯</td><td>    0</td><td>   15</td><td>   13</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td></tr>
	<tr><th scope=row>AADACL2</th><td>  0</td><td>   0</td><td>   0</td><td>   3</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>⋯</td><td>    0</td><td>    1</td><td>    8</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td></tr>
	<tr><th scope=row>AADACL2-AS1</th><td>  0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>⋯</td><td>    0</td><td>    0</td><td>    1</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td></tr>
	<tr><th scope=row>AADACL3</th><td>  0</td><td>   0</td><td>   0</td><td>   1</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>⋯</td><td>    0</td><td>    0</td><td>    0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   1</td><td>   0</td><td>   0</td></tr>
	<tr><th scope=row>AADACL4</th><td>  0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   1</td><td>⋯</td><td>    1</td><td>    0</td><td>    1</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   1</td></tr>
	<tr><th scope=row>AADACP1</th><td>  0</td><td>   1</td><td>   0</td><td>   0</td><td>   2</td><td>   3</td><td>   6</td><td>   5</td><td>   3</td><td>   0</td><td>⋯</td><td>    6</td><td>    0</td><td>    3</td><td>   0</td><td>   1</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td></tr>
	<tr><th scope=row>AADAT</th><td>238</td><td> 230</td><td> 398</td><td> 488</td><td> 352</td><td> 365</td><td> 304</td><td> 333</td><td> 198</td><td> 166</td><td>⋯</td><td>  709</td><td>  515</td><td>  461</td><td> 266</td><td> 231</td><td> 193</td><td> 192</td><td> 130</td><td>  17</td><td>  31</td></tr>
	<tr><th scope=row>AAGAB</th><td>408</td><td> 422</td><td> 811</td><td>1687</td><td>1438</td><td>1382</td><td>1353</td><td>1444</td><td> 741</td><td> 788</td><td>⋯</td><td> 1410</td><td> 1140</td><td>  864</td><td>1064</td><td>1282</td><td>1218</td><td>1545</td><td> 986</td><td>  83</td><td>  96</td></tr>
	<tr><th scope=row>AAK1</th><td>879</td><td>1142</td><td> 848</td><td>1026</td><td>1452</td><td>1609</td><td>1535</td><td>1593</td><td>1277</td><td> 665</td><td>⋯</td><td> 1935</td><td> 1877</td><td> 1403</td><td> 336</td><td> 408</td><td> 299</td><td> 870</td><td> 530</td><td> 133</td><td> 220</td></tr>
	<tr><th scope=row>AAMDC</th><td> 47</td><td>  44</td><td>  86</td><td>  93</td><td>  89</td><td> 103</td><td> 113</td><td> 139</td><td> 136</td><td>  55</td><td>⋯</td><td>  401</td><td>  363</td><td>  255</td><td>  38</td><td>  44</td><td>  46</td><td> 161</td><td> 108</td><td>  13</td><td>  15</td></tr>
	<tr><th scope=row>AAMP</th><td>712</td><td> 749</td><td>1507</td><td>2717</td><td>2144</td><td>2117</td><td>2292</td><td>2370</td><td>1575</td><td>1691</td><td>⋯</td><td> 4699</td><td> 3905</td><td> 3014</td><td>1215</td><td>1211</td><td>1282</td><td>4176</td><td>2538</td><td> 181</td><td> 299</td></tr>
	<tr><th scope=row>⋮</th><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋱</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td></tr>
	<tr><th scope=row>ZSCAN5C</th><td>   0</td><td>   1</td><td>   0</td><td>   0</td><td>   2</td><td>   0</td><td>    0</td><td>    1</td><td>    2</td><td>   0</td><td>⋯</td><td>   0</td><td>   1</td><td>   3</td><td>   3</td><td>   1</td><td>   2</td><td>   2</td><td>   0</td><td>  1</td><td>  0</td></tr>
	<tr><th scope=row>ZSCAN5DP</th><td>   1</td><td>   2</td><td>   0</td><td>   1</td><td>   0</td><td>   0</td><td>    0</td><td>    0</td><td>    0</td><td>   0</td><td>⋯</td><td>   4</td><td>   1</td><td>   0</td><td>   2</td><td>   5</td><td>   0</td><td>  13</td><td>   2</td><td>  0</td><td>  1</td></tr>
	<tr><th scope=row>ZSCAN9</th><td> 184</td><td> 193</td><td> 409</td><td> 614</td><td> 240</td><td> 216</td><td>  240</td><td>  222</td><td>  108</td><td> 208</td><td>⋯</td><td>1015</td><td> 775</td><td> 643</td><td> 494</td><td> 551</td><td> 428</td><td> 598</td><td> 367</td><td> 55</td><td> 58</td></tr>
	<tr><th scope=row>ZSWIM1</th><td> 195</td><td> 184</td><td> 214</td><td> 289</td><td> 199</td><td> 205</td><td>  180</td><td>  160</td><td>   90</td><td> 138</td><td>⋯</td><td> 582</td><td> 476</td><td> 427</td><td> 128</td><td> 156</td><td> 114</td><td> 377</td><td> 201</td><td> 75</td><td> 85</td></tr>
	<tr><th scope=row>ZSWIM2</th><td>   1</td><td>   2</td><td>   1</td><td>   2</td><td>   0</td><td>   0</td><td>    0</td><td>    0</td><td>    0</td><td>   2</td><td>⋯</td><td>   2</td><td>   2</td><td>   1</td><td>   2</td><td>   2</td><td>   1</td><td>   3</td><td>   2</td><td>  0</td><td>  0</td></tr>
	<tr><th scope=row>ZSWIM3</th><td>  61</td><td>  73</td><td> 116</td><td> 150</td><td> 113</td><td>  79</td><td>  105</td><td>  106</td><td>   33</td><td> 112</td><td>⋯</td><td> 306</td><td> 210</td><td> 210</td><td> 161</td><td> 195</td><td> 190</td><td> 232</td><td> 165</td><td> 24</td><td> 14</td></tr>
	<tr><th scope=row>ZSWIM4</th><td> 113</td><td> 137</td><td> 117</td><td> 147</td><td>  69</td><td>  68</td><td>   88</td><td>   79</td><td>   22</td><td> 181</td><td>⋯</td><td> 285</td><td> 227</td><td> 178</td><td> 212</td><td> 266</td><td> 224</td><td> 433</td><td> 279</td><td> 32</td><td> 62</td></tr>
	<tr><th scope=row>ZSWIM5</th><td>  74</td><td>  84</td><td> 145</td><td> 122</td><td>   4</td><td>   1</td><td>    2</td><td>    6</td><td>    2</td><td> 138</td><td>⋯</td><td>  78</td><td>  29</td><td>  37</td><td> 811</td><td> 924</td><td> 893</td><td> 223</td><td> 214</td><td> 20</td><td> 11</td></tr>
	<tr><th scope=row>ZSWIM5P1</th><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>    0</td><td>    0</td><td>    0</td><td>   0</td><td>⋯</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>  0</td><td>  0</td></tr>
	<tr><th scope=row>ZSWIM5P2</th><td>   0</td><td>   0</td><td>   2</td><td>   0</td><td>   0</td><td>   0</td><td>    0</td><td>    0</td><td>    0</td><td>   0</td><td>⋯</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>  0</td><td>  0</td></tr>
	<tr><th scope=row>ZSWIM5P3</th><td>   0</td><td>   0</td><td>   0</td><td>   2</td><td>   0</td><td>   0</td><td>    0</td><td>    0</td><td>   10</td><td>   0</td><td>⋯</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>  11</td><td>   1</td><td>  3</td><td>  7</td></tr>
	<tr><th scope=row>ZSWIM6</th><td> 537</td><td> 702</td><td>1154</td><td>1399</td><td>1011</td><td>1066</td><td>  988</td><td> 1108</td><td>  173</td><td> 491</td><td>⋯</td><td>1252</td><td> 980</td><td> 868</td><td>1428</td><td>1572</td><td>1440</td><td>1104</td><td> 899</td><td> 93</td><td>144</td></tr>
	<tr><th scope=row>ZSWIM7</th><td> 205</td><td> 317</td><td> 518</td><td> 489</td><td> 220</td><td> 224</td><td>  230</td><td>  265</td><td>  204</td><td> 215</td><td>⋯</td><td> 898</td><td> 653</td><td> 715</td><td> 280</td><td> 316</td><td> 282</td><td> 626</td><td> 379</td><td> 56</td><td> 61</td></tr>
	<tr><th scope=row>ZSWIM8</th><td> 504</td><td> 689</td><td> 711</td><td> 912</td><td> 690</td><td> 809</td><td>  934</td><td>  852</td><td>  240</td><td> 800</td><td>⋯</td><td>3324</td><td>2906</td><td>2482</td><td> 658</td><td> 705</td><td> 528</td><td>1423</td><td>1053</td><td>131</td><td>231</td></tr>
	<tr><th scope=row>ZSWIM8-AS1</th><td>   0</td><td>   0</td><td>   1</td><td>   0</td><td>   0</td><td>   0</td><td>    0</td><td>    0</td><td>    0</td><td>   0</td><td>⋯</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>  0</td><td>  0</td></tr>
	<tr><th scope=row>ZSWIM9</th><td>  35</td><td>  30</td><td>  64</td><td>  54</td><td> 189</td><td> 194</td><td>  162</td><td>  173</td><td>  178</td><td> 151</td><td>⋯</td><td> 894</td><td> 592</td><td> 499</td><td>  76</td><td>  86</td><td>  60</td><td>  69</td><td>  30</td><td> 32</td><td> 61</td></tr>
	<tr><th scope=row>ZUP1</th><td> 228</td><td> 262</td><td> 611</td><td> 754</td><td> 255</td><td> 305</td><td>  258</td><td>  316</td><td>  160</td><td> 165</td><td>⋯</td><td> 525</td><td> 349</td><td> 267</td><td> 497</td><td> 550</td><td> 497</td><td> 770</td><td> 553</td><td> 59</td><td> 76</td></tr>
	<tr><th scope=row>ZW10</th><td> 470</td><td> 444</td><td> 765</td><td>1597</td><td>1244</td><td>1197</td><td> 1025</td><td> 1172</td><td>  509</td><td> 456</td><td>⋯</td><td>1457</td><td> 995</td><td> 860</td><td> 354</td><td> 480</td><td> 401</td><td>1054</td><td> 712</td><td> 71</td><td> 88</td></tr>
	<tr><th scope=row>ZWILCH</th><td> 390</td><td> 443</td><td> 803</td><td>1603</td><td>1736</td><td>1671</td><td> 1484</td><td> 1786</td><td>  430</td><td> 268</td><td>⋯</td><td>1256</td><td> 823</td><td> 766</td><td> 455</td><td> 533</td><td> 446</td><td> 803</td><td> 575</td><td> 40</td><td> 63</td></tr>
	<tr><th scope=row>ZWINT</th><td> 645</td><td> 575</td><td>1205</td><td>2960</td><td>2787</td><td>2757</td><td> 2984</td><td> 3428</td><td> 1303</td><td> 164</td><td>⋯</td><td>1604</td><td> 977</td><td> 963</td><td> 292</td><td> 347</td><td> 310</td><td> 538</td><td> 456</td><td> 20</td><td> 22</td></tr>
	<tr><th scope=row>ZXDA</th><td>   0</td><td>   0</td><td>   1</td><td>   0</td><td>  55</td><td>  52</td><td>   65</td><td>   72</td><td>    0</td><td>   0</td><td>⋯</td><td> 365</td><td> 265</td><td> 224</td><td> 136</td><td> 154</td><td> 131</td><td> 419</td><td> 198</td><td> 35</td><td> 52</td></tr>
	<tr><th scope=row>ZXDB</th><td> 189</td><td> 235</td><td> 286</td><td> 467</td><td> 277</td><td> 299</td><td>  235</td><td>  271</td><td>   78</td><td> 254</td><td>⋯</td><td> 747</td><td> 584</td><td> 502</td><td> 150</td><td> 183</td><td> 145</td><td> 586</td><td> 334</td><td>110</td><td>131</td></tr>
	<tr><th scope=row>ZXDC</th><td> 406</td><td> 538</td><td> 555</td><td> 938</td><td> 357</td><td> 433</td><td>  440</td><td>  359</td><td>  182</td><td> 605</td><td>⋯</td><td>1700</td><td>1588</td><td>1334</td><td> 559</td><td> 611</td><td> 529</td><td>1418</td><td>1029</td><td>156</td><td>214</td></tr>
	<tr><th scope=row>ZYG11A</th><td>  23</td><td>  35</td><td>  46</td><td> 109</td><td> 124</td><td> 103</td><td>   78</td><td>  114</td><td>   11</td><td>   2</td><td>⋯</td><td>   2</td><td>   5</td><td>   1</td><td>   7</td><td>   5</td><td>   2</td><td>  13</td><td>  13</td><td>  1</td><td>  1</td></tr>
	<tr><th scope=row>ZYG11AP1</th><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>    0</td><td>    0</td><td>    0</td><td>   0</td><td>⋯</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>  0</td><td>  0</td></tr>
	<tr><th scope=row>ZYG11B</th><td>1386</td><td>1513</td><td>2747</td><td>4320</td><td>1331</td><td>1445</td><td> 1159</td><td> 1307</td><td>  527</td><td>1290</td><td>⋯</td><td>6313</td><td>5993</td><td>4926</td><td>1619</td><td>1897</td><td>1623</td><td>7116</td><td>4357</td><td>507</td><td>659</td></tr>
	<tr><th scope=row>ZYX</th><td> 765</td><td> 958</td><td> 698</td><td>1272</td><td>8971</td><td>8748</td><td>11856</td><td>10480</td><td>12797</td><td>4329</td><td>⋯</td><td>9132</td><td>9468</td><td>8457</td><td> 676</td><td> 789</td><td> 654</td><td>2988</td><td>1680</td><td>213</td><td>361</td></tr>
	<tr><th scope=row>ZYXP1</th><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>    0</td><td>    0</td><td>    0</td><td>   0</td><td>⋯</td><td>   1</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>  0</td><td>  0</td></tr>
	<tr><th scope=row>ZZEF1</th><td> 803</td><td> 985</td><td>1171</td><td>1511</td><td> 862</td><td> 888</td><td>  939</td><td>  967</td><td>  342</td><td> 933</td><td>⋯</td><td>4052</td><td>4373</td><td>3234</td><td> 847</td><td> 904</td><td> 804</td><td>3796</td><td>2545</td><td>307</td><td>601</td></tr>
	<tr><th scope=row>ZZZ3</th><td>1280</td><td>1324</td><td>2632</td><td>3543</td><td>1753</td><td>1740</td><td> 1737</td><td> 1787</td><td>  353</td><td> 857</td><td>⋯</td><td>3581</td><td>2717</td><td>2161</td><td>1647</td><td>1867</td><td>1724</td><td>4863</td><td>2799</td><td>360</td><td>377</td></tr>
</tbody>
</table>




```R
write.table(MT1, "/staging/leuven/stg_00134/Margaux/PCAsamplesused.tsv", sep="\t", col.names=NA, quote=FALSE)
```


```R
MT1.m <- as.matrix(MT1)
MT1.m
```


<table class="dataframe">
<caption>A matrix: 61228 × 418 of type int</caption>
<thead>
	<tr><th></th><th scope=col>1D_MP1</th><th scope=col>1D_MP2</th><th scope=col>1D_MP3</th><th scope=col>1D_MP4</th><th scope=col>9D_MP1</th><th scope=col>9D_MP2</th><th scope=col>9D_MP3</th><th scope=col>9D_MP4</th><th scope=col>10D_MP1</th><th scope=col>10D_MP2</th><th scope=col>⋯</th><th scope=col>62F_FSM7</th><th scope=col>62F_FSM8</th><th scope=col>62F_FSM9</th><th scope=col>63_3D_04w_01</th><th scope=col>63_3D_04w_02</th><th scope=col>63_3D_04w_03</th><th scope=col>63_3D_08w_01</th><th scope=col>63_3D_08w_02</th><th scope=col>63_3D_16w_01</th><th scope=col>63_3D_16w_02</th></tr>
</thead>
<tbody>
	<tr><th scope=row>5_8S_rRNA</th><td>  0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>⋯</td><td>    1</td><td>    0</td><td>    0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>  33</td><td>  25</td></tr>
	<tr><th scope=row>5S_rRNA</th><td>  1</td><td>   3</td><td>   9</td><td>   5</td><td>   1</td><td>   0</td><td>   0</td><td>   1</td><td>   0</td><td>   0</td><td>⋯</td><td>    1</td><td>    0</td><td>    2</td><td>   3</td><td>   0</td><td>   1</td><td>   0</td><td>   0</td><td>   4</td><td>   6</td></tr>
	<tr><th scope=row>7SK</th><td> 10</td><td>  15</td><td>   8</td><td>  13</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>⋯</td><td>    0</td><td>    1</td><td>    0</td><td>  13</td><td>  15</td><td>  22</td><td>  21</td><td>   2</td><td>   0</td><td>   2</td></tr>
	<tr><th scope=row>A1BG</th><td> 15</td><td>  22</td><td>  23</td><td>  23</td><td>  10</td><td>   4</td><td>   4</td><td>   3</td><td>   3</td><td>   2</td><td>⋯</td><td>    5</td><td>    2</td><td>    7</td><td>  16</td><td>  23</td><td>  23</td><td>  26</td><td>  32</td><td>  10</td><td>  11</td></tr>
	<tr><th scope=row>A1BG-AS1</th><td> 43</td><td>  47</td><td>  59</td><td>  87</td><td>  44</td><td>  50</td><td>  54</td><td>  51</td><td>  29</td><td>  42</td><td>⋯</td><td>   30</td><td>   35</td><td>   18</td><td>  54</td><td>  56</td><td>  38</td><td> 127</td><td>  64</td><td>  12</td><td>  16</td></tr>
	<tr><th scope=row>A1CF</th><td> 10</td><td>  11</td><td>  22</td><td>  24</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   1</td><td>⋯</td><td>    7</td><td>   20</td><td>    2</td><td>   2</td><td>   0</td><td>   0</td><td>   4</td><td>   7</td><td>   1</td><td>   2</td></tr>
	<tr><th scope=row>A2M</th><td>122</td><td> 135</td><td> 237</td><td> 323</td><td> 442</td><td> 451</td><td> 371</td><td> 366</td><td>  31</td><td>3338</td><td>⋯</td><td>37580</td><td>26320</td><td>20334</td><td>  27</td><td>  20</td><td>  23</td><td>2156</td><td>1021</td><td>1055</td><td>2552</td></tr>
	<tr><th scope=row>A2M-AS1</th><td> 55</td><td>  53</td><td>  94</td><td>  97</td><td>  41</td><td>  39</td><td>  37</td><td>  27</td><td>   8</td><td>  91</td><td>⋯</td><td>  147</td><td>   81</td><td>   78</td><td>  63</td><td>  77</td><td>  56</td><td> 110</td><td>  62</td><td>   8</td><td>  23</td></tr>
	<tr><th scope=row>A2ML1</th><td>  1</td><td>   3</td><td>   8</td><td>  14</td><td>   1</td><td>   1</td><td>   0</td><td>   0</td><td>   1</td><td>   0</td><td>⋯</td><td>    3</td><td>    1</td><td>   66</td><td>   4</td><td>   3</td><td>   1</td><td>   7</td><td>   1</td><td>   1</td><td>   1</td></tr>
	<tr><th scope=row>A2ML1-AS1</th><td>  0</td><td>   0</td><td>   1</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   1</td><td>⋯</td><td>    0</td><td>    0</td><td>    0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td></tr>
	<tr><th scope=row>A2ML1-AS2</th><td>  0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>⋯</td><td>    0</td><td>    0</td><td>    0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td></tr>
	<tr><th scope=row>A2MP1</th><td>  6</td><td>   9</td><td>  13</td><td>  12</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>⋯</td><td>   11</td><td>   16</td><td>   10</td><td>   3</td><td>   5</td><td>   7</td><td>   9</td><td>   1</td><td>   2</td><td>   1</td></tr>
	<tr><th scope=row>A3GALT2</th><td>  5</td><td>   4</td><td>   6</td><td>   3</td><td>   1</td><td>   1</td><td>   4</td><td>   1</td><td>   0</td><td>   0</td><td>⋯</td><td>    1</td><td>    4</td><td>    0</td><td>   1</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td></tr>
	<tr><th scope=row>A4GALT</th><td>  7</td><td>  11</td><td>   6</td><td>  30</td><td> 174</td><td> 214</td><td> 417</td><td> 336</td><td> 142</td><td> 125</td><td>⋯</td><td> 1145</td><td> 1114</td><td>  935</td><td>   4</td><td>   2</td><td>   5</td><td> 242</td><td> 158</td><td>  39</td><td>  59</td></tr>
	<tr><th scope=row>A4GNT</th><td>  0</td><td>   1</td><td>   1</td><td>   3</td><td>   0</td><td>   1</td><td>   4</td><td>   2</td><td>   0</td><td>   0</td><td>⋯</td><td>    1</td><td>    0</td><td>    2</td><td>   0</td><td>   0</td><td>   0</td><td>   2</td><td>   0</td><td>   2</td><td>   0</td></tr>
	<tr><th scope=row>AA06</th><td>  0</td><td>   0</td><td>   1</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>⋯</td><td>    0</td><td>    0</td><td>    0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td></tr>
	<tr><th scope=row>AAAS</th><td>629</td><td> 628</td><td>1021</td><td>1854</td><td>1132</td><td> 999</td><td>1104</td><td>1118</td><td>1007</td><td>1021</td><td>⋯</td><td> 2164</td><td> 1701</td><td> 1577</td><td> 635</td><td> 693</td><td> 622</td><td>1495</td><td>1053</td><td> 109</td><td> 145</td></tr>
	<tr><th scope=row>AACS</th><td>363</td><td> 397</td><td> 612</td><td> 673</td><td> 514</td><td> 543</td><td> 504</td><td> 554</td><td> 588</td><td> 719</td><td>⋯</td><td> 2148</td><td> 1875</td><td> 2276</td><td> 358</td><td> 436</td><td> 379</td><td>2015</td><td>1139</td><td> 134</td><td> 197</td></tr>
	<tr><th scope=row>AACSP1</th><td> 33</td><td>  20</td><td>   3</td><td>  29</td><td>   1</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   2</td><td>⋯</td><td>    2</td><td>    5</td><td>    6</td><td>   1</td><td>   2</td><td>   3</td><td>   5</td><td>   3</td><td>   0</td><td>   2</td></tr>
	<tr><th scope=row>AADAC</th><td>  0</td><td>   0</td><td>   0</td><td>   0</td><td>   2</td><td>   2</td><td>   3</td><td>   6</td><td>  15</td><td>   0</td><td>⋯</td><td>    0</td><td>   15</td><td>   13</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td></tr>
	<tr><th scope=row>AADACL2</th><td>  0</td><td>   0</td><td>   0</td><td>   3</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>⋯</td><td>    0</td><td>    1</td><td>    8</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td></tr>
	<tr><th scope=row>AADACL2-AS1</th><td>  0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>⋯</td><td>    0</td><td>    0</td><td>    1</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td></tr>
	<tr><th scope=row>AADACL3</th><td>  0</td><td>   0</td><td>   0</td><td>   1</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>⋯</td><td>    0</td><td>    0</td><td>    0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   1</td><td>   0</td><td>   0</td></tr>
	<tr><th scope=row>AADACL4</th><td>  0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   1</td><td>⋯</td><td>    1</td><td>    0</td><td>    1</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   1</td></tr>
	<tr><th scope=row>AADACP1</th><td>  0</td><td>   1</td><td>   0</td><td>   0</td><td>   2</td><td>   3</td><td>   6</td><td>   5</td><td>   3</td><td>   0</td><td>⋯</td><td>    6</td><td>    0</td><td>    3</td><td>   0</td><td>   1</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td></tr>
	<tr><th scope=row>AADAT</th><td>238</td><td> 230</td><td> 398</td><td> 488</td><td> 352</td><td> 365</td><td> 304</td><td> 333</td><td> 198</td><td> 166</td><td>⋯</td><td>  709</td><td>  515</td><td>  461</td><td> 266</td><td> 231</td><td> 193</td><td> 192</td><td> 130</td><td>  17</td><td>  31</td></tr>
	<tr><th scope=row>AAGAB</th><td>408</td><td> 422</td><td> 811</td><td>1687</td><td>1438</td><td>1382</td><td>1353</td><td>1444</td><td> 741</td><td> 788</td><td>⋯</td><td> 1410</td><td> 1140</td><td>  864</td><td>1064</td><td>1282</td><td>1218</td><td>1545</td><td> 986</td><td>  83</td><td>  96</td></tr>
	<tr><th scope=row>AAK1</th><td>879</td><td>1142</td><td> 848</td><td>1026</td><td>1452</td><td>1609</td><td>1535</td><td>1593</td><td>1277</td><td> 665</td><td>⋯</td><td> 1935</td><td> 1877</td><td> 1403</td><td> 336</td><td> 408</td><td> 299</td><td> 870</td><td> 530</td><td> 133</td><td> 220</td></tr>
	<tr><th scope=row>AAMDC</th><td> 47</td><td>  44</td><td>  86</td><td>  93</td><td>  89</td><td> 103</td><td> 113</td><td> 139</td><td> 136</td><td>  55</td><td>⋯</td><td>  401</td><td>  363</td><td>  255</td><td>  38</td><td>  44</td><td>  46</td><td> 161</td><td> 108</td><td>  13</td><td>  15</td></tr>
	<tr><th scope=row>AAMP</th><td>712</td><td> 749</td><td>1507</td><td>2717</td><td>2144</td><td>2117</td><td>2292</td><td>2370</td><td>1575</td><td>1691</td><td>⋯</td><td> 4699</td><td> 3905</td><td> 3014</td><td>1215</td><td>1211</td><td>1282</td><td>4176</td><td>2538</td><td> 181</td><td> 299</td></tr>
	<tr><th scope=row>⋮</th><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋱</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td></tr>
	<tr><th scope=row>ZSCAN5C</th><td>   0</td><td>   1</td><td>   0</td><td>   0</td><td>   2</td><td>   0</td><td>    0</td><td>    1</td><td>    2</td><td>   0</td><td>⋯</td><td>   0</td><td>   1</td><td>   3</td><td>   3</td><td>   1</td><td>   2</td><td>   2</td><td>   0</td><td>  1</td><td>  0</td></tr>
	<tr><th scope=row>ZSCAN5DP</th><td>   1</td><td>   2</td><td>   0</td><td>   1</td><td>   0</td><td>   0</td><td>    0</td><td>    0</td><td>    0</td><td>   0</td><td>⋯</td><td>   4</td><td>   1</td><td>   0</td><td>   2</td><td>   5</td><td>   0</td><td>  13</td><td>   2</td><td>  0</td><td>  1</td></tr>
	<tr><th scope=row>ZSCAN9</th><td> 184</td><td> 193</td><td> 409</td><td> 614</td><td> 240</td><td> 216</td><td>  240</td><td>  222</td><td>  108</td><td> 208</td><td>⋯</td><td>1015</td><td> 775</td><td> 643</td><td> 494</td><td> 551</td><td> 428</td><td> 598</td><td> 367</td><td> 55</td><td> 58</td></tr>
	<tr><th scope=row>ZSWIM1</th><td> 195</td><td> 184</td><td> 214</td><td> 289</td><td> 199</td><td> 205</td><td>  180</td><td>  160</td><td>   90</td><td> 138</td><td>⋯</td><td> 582</td><td> 476</td><td> 427</td><td> 128</td><td> 156</td><td> 114</td><td> 377</td><td> 201</td><td> 75</td><td> 85</td></tr>
	<tr><th scope=row>ZSWIM2</th><td>   1</td><td>   2</td><td>   1</td><td>   2</td><td>   0</td><td>   0</td><td>    0</td><td>    0</td><td>    0</td><td>   2</td><td>⋯</td><td>   2</td><td>   2</td><td>   1</td><td>   2</td><td>   2</td><td>   1</td><td>   3</td><td>   2</td><td>  0</td><td>  0</td></tr>
	<tr><th scope=row>ZSWIM3</th><td>  61</td><td>  73</td><td> 116</td><td> 150</td><td> 113</td><td>  79</td><td>  105</td><td>  106</td><td>   33</td><td> 112</td><td>⋯</td><td> 306</td><td> 210</td><td> 210</td><td> 161</td><td> 195</td><td> 190</td><td> 232</td><td> 165</td><td> 24</td><td> 14</td></tr>
	<tr><th scope=row>ZSWIM4</th><td> 113</td><td> 137</td><td> 117</td><td> 147</td><td>  69</td><td>  68</td><td>   88</td><td>   79</td><td>   22</td><td> 181</td><td>⋯</td><td> 285</td><td> 227</td><td> 178</td><td> 212</td><td> 266</td><td> 224</td><td> 433</td><td> 279</td><td> 32</td><td> 62</td></tr>
	<tr><th scope=row>ZSWIM5</th><td>  74</td><td>  84</td><td> 145</td><td> 122</td><td>   4</td><td>   1</td><td>    2</td><td>    6</td><td>    2</td><td> 138</td><td>⋯</td><td>  78</td><td>  29</td><td>  37</td><td> 811</td><td> 924</td><td> 893</td><td> 223</td><td> 214</td><td> 20</td><td> 11</td></tr>
	<tr><th scope=row>ZSWIM5P1</th><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>    0</td><td>    0</td><td>    0</td><td>   0</td><td>⋯</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>  0</td><td>  0</td></tr>
	<tr><th scope=row>ZSWIM5P2</th><td>   0</td><td>   0</td><td>   2</td><td>   0</td><td>   0</td><td>   0</td><td>    0</td><td>    0</td><td>    0</td><td>   0</td><td>⋯</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>  0</td><td>  0</td></tr>
	<tr><th scope=row>ZSWIM5P3</th><td>   0</td><td>   0</td><td>   0</td><td>   2</td><td>   0</td><td>   0</td><td>    0</td><td>    0</td><td>   10</td><td>   0</td><td>⋯</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>  11</td><td>   1</td><td>  3</td><td>  7</td></tr>
	<tr><th scope=row>ZSWIM6</th><td> 537</td><td> 702</td><td>1154</td><td>1399</td><td>1011</td><td>1066</td><td>  988</td><td> 1108</td><td>  173</td><td> 491</td><td>⋯</td><td>1252</td><td> 980</td><td> 868</td><td>1428</td><td>1572</td><td>1440</td><td>1104</td><td> 899</td><td> 93</td><td>144</td></tr>
	<tr><th scope=row>ZSWIM7</th><td> 205</td><td> 317</td><td> 518</td><td> 489</td><td> 220</td><td> 224</td><td>  230</td><td>  265</td><td>  204</td><td> 215</td><td>⋯</td><td> 898</td><td> 653</td><td> 715</td><td> 280</td><td> 316</td><td> 282</td><td> 626</td><td> 379</td><td> 56</td><td> 61</td></tr>
	<tr><th scope=row>ZSWIM8</th><td> 504</td><td> 689</td><td> 711</td><td> 912</td><td> 690</td><td> 809</td><td>  934</td><td>  852</td><td>  240</td><td> 800</td><td>⋯</td><td>3324</td><td>2906</td><td>2482</td><td> 658</td><td> 705</td><td> 528</td><td>1423</td><td>1053</td><td>131</td><td>231</td></tr>
	<tr><th scope=row>ZSWIM8-AS1</th><td>   0</td><td>   0</td><td>   1</td><td>   0</td><td>   0</td><td>   0</td><td>    0</td><td>    0</td><td>    0</td><td>   0</td><td>⋯</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>  0</td><td>  0</td></tr>
	<tr><th scope=row>ZSWIM9</th><td>  35</td><td>  30</td><td>  64</td><td>  54</td><td> 189</td><td> 194</td><td>  162</td><td>  173</td><td>  178</td><td> 151</td><td>⋯</td><td> 894</td><td> 592</td><td> 499</td><td>  76</td><td>  86</td><td>  60</td><td>  69</td><td>  30</td><td> 32</td><td> 61</td></tr>
	<tr><th scope=row>ZUP1</th><td> 228</td><td> 262</td><td> 611</td><td> 754</td><td> 255</td><td> 305</td><td>  258</td><td>  316</td><td>  160</td><td> 165</td><td>⋯</td><td> 525</td><td> 349</td><td> 267</td><td> 497</td><td> 550</td><td> 497</td><td> 770</td><td> 553</td><td> 59</td><td> 76</td></tr>
	<tr><th scope=row>ZW10</th><td> 470</td><td> 444</td><td> 765</td><td>1597</td><td>1244</td><td>1197</td><td> 1025</td><td> 1172</td><td>  509</td><td> 456</td><td>⋯</td><td>1457</td><td> 995</td><td> 860</td><td> 354</td><td> 480</td><td> 401</td><td>1054</td><td> 712</td><td> 71</td><td> 88</td></tr>
	<tr><th scope=row>ZWILCH</th><td> 390</td><td> 443</td><td> 803</td><td>1603</td><td>1736</td><td>1671</td><td> 1484</td><td> 1786</td><td>  430</td><td> 268</td><td>⋯</td><td>1256</td><td> 823</td><td> 766</td><td> 455</td><td> 533</td><td> 446</td><td> 803</td><td> 575</td><td> 40</td><td> 63</td></tr>
	<tr><th scope=row>ZWINT</th><td> 645</td><td> 575</td><td>1205</td><td>2960</td><td>2787</td><td>2757</td><td> 2984</td><td> 3428</td><td> 1303</td><td> 164</td><td>⋯</td><td>1604</td><td> 977</td><td> 963</td><td> 292</td><td> 347</td><td> 310</td><td> 538</td><td> 456</td><td> 20</td><td> 22</td></tr>
	<tr><th scope=row>ZXDA</th><td>   0</td><td>   0</td><td>   1</td><td>   0</td><td>  55</td><td>  52</td><td>   65</td><td>   72</td><td>    0</td><td>   0</td><td>⋯</td><td> 365</td><td> 265</td><td> 224</td><td> 136</td><td> 154</td><td> 131</td><td> 419</td><td> 198</td><td> 35</td><td> 52</td></tr>
	<tr><th scope=row>ZXDB</th><td> 189</td><td> 235</td><td> 286</td><td> 467</td><td> 277</td><td> 299</td><td>  235</td><td>  271</td><td>   78</td><td> 254</td><td>⋯</td><td> 747</td><td> 584</td><td> 502</td><td> 150</td><td> 183</td><td> 145</td><td> 586</td><td> 334</td><td>110</td><td>131</td></tr>
	<tr><th scope=row>ZXDC</th><td> 406</td><td> 538</td><td> 555</td><td> 938</td><td> 357</td><td> 433</td><td>  440</td><td>  359</td><td>  182</td><td> 605</td><td>⋯</td><td>1700</td><td>1588</td><td>1334</td><td> 559</td><td> 611</td><td> 529</td><td>1418</td><td>1029</td><td>156</td><td>214</td></tr>
	<tr><th scope=row>ZYG11A</th><td>  23</td><td>  35</td><td>  46</td><td> 109</td><td> 124</td><td> 103</td><td>   78</td><td>  114</td><td>   11</td><td>   2</td><td>⋯</td><td>   2</td><td>   5</td><td>   1</td><td>   7</td><td>   5</td><td>   2</td><td>  13</td><td>  13</td><td>  1</td><td>  1</td></tr>
	<tr><th scope=row>ZYG11AP1</th><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>    0</td><td>    0</td><td>    0</td><td>   0</td><td>⋯</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>  0</td><td>  0</td></tr>
	<tr><th scope=row>ZYG11B</th><td>1386</td><td>1513</td><td>2747</td><td>4320</td><td>1331</td><td>1445</td><td> 1159</td><td> 1307</td><td>  527</td><td>1290</td><td>⋯</td><td>6313</td><td>5993</td><td>4926</td><td>1619</td><td>1897</td><td>1623</td><td>7116</td><td>4357</td><td>507</td><td>659</td></tr>
	<tr><th scope=row>ZYX</th><td> 765</td><td> 958</td><td> 698</td><td>1272</td><td>8971</td><td>8748</td><td>11856</td><td>10480</td><td>12797</td><td>4329</td><td>⋯</td><td>9132</td><td>9468</td><td>8457</td><td> 676</td><td> 789</td><td> 654</td><td>2988</td><td>1680</td><td>213</td><td>361</td></tr>
	<tr><th scope=row>ZYXP1</th><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>    0</td><td>    0</td><td>    0</td><td>   0</td><td>⋯</td><td>   1</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>  0</td><td>  0</td></tr>
	<tr><th scope=row>ZZEF1</th><td> 803</td><td> 985</td><td>1171</td><td>1511</td><td> 862</td><td> 888</td><td>  939</td><td>  967</td><td>  342</td><td> 933</td><td>⋯</td><td>4052</td><td>4373</td><td>3234</td><td> 847</td><td> 904</td><td> 804</td><td>3796</td><td>2545</td><td>307</td><td>601</td></tr>
	<tr><th scope=row>ZZZ3</th><td>1280</td><td>1324</td><td>2632</td><td>3543</td><td>1753</td><td>1740</td><td> 1737</td><td> 1787</td><td>  353</td><td> 857</td><td>⋯</td><td>3581</td><td>2717</td><td>2161</td><td>1647</td><td>1867</td><td>1724</td><td>4863</td><td>2799</td><td>360</td><td>377</td></tr>
</tbody>
</table>




```R
DGE_MT1 <- DGEList(MT1.m)
cpmMT1 <- cpm(DGE_MT1)
log2.cpm_MT1 <- cpm(DGE_MT1, log=TRUE)
table(rowSums(DGE_MT1$counts==0)==418)
```


    
    FALSE  TRUE 
    57027  4201 



```R
cpmMT1["SIRT1",]
```


<style>
.dl-inline {width: auto; margin:0; padding: 0}
.dl-inline>dt, .dl-inline>dd {float: none; width: auto; display: inline-block}
.dl-inline>dt::after {content: ":\0020"; padding-right: .5ex}
.dl-inline>dt:not(:first-of-type) {padding-left: .5ex}
</style><dl class=dl-inline><dt>1D_MP1</dt><dd>48.9970865711235</dd><dt>1D_MP2</dt><dd>42.8519965812583</dd><dt>1D_MP3</dt><dd>63.5934343882697</dd><dt>1D_MP4</dt><dd>70.2493410828261</dd><dt>9D_MP1</dt><dd>44.6263499470859</dd><dt>9D_MP2</dt><dd>43.4754968872846</dd><dt>9D_MP3</dt><dd>43.6666984611195</dd><dt>9D_MP4</dt><dd>46.8537172414891</dd><dt>10D_MP1</dt><dd>17.1668431176906</dd><dt>10D_MP2</dt><dd>35.9623971389974</dd><dt>12D_MP_L9</dt><dd>44.1567014619714</dd><dt>12D_MP_L10</dt><dd>47.7018183680676</dd><dt>12D_MP_L11</dt><dd>33.4662984263583</dd><dt>12D_MP_L12</dt><dd>32.7264284531335</dd><dt>13D_MP1</dt><dd>43.4585538286268</dd><dt>13D_MP2</dt><dd>39.1371698269839</dd><dt>13D_MP3</dt><dd>49.9602578044465</dd><dt>13D_MP4</dt><dd>39.9746434065212</dd><dt>13D_MP5</dt><dd>38.9932435611302</dd><dt>17D_MP1</dt><dd>48.17751603381</dd><dt>17D_MP2</dt><dd>46.5447452357583</dd><dt>17D_MP3</dt><dd>42.7194533519134</dd><dt>17D_MP4</dt><dd>42.4051914797708</dd><dt>17D_MP5</dt><dd>42.0336195232298</dd><dt>17D_MP6</dt><dd>42.3031475776485</dd><dt>17D_MP7</dt><dd>34.4965528087586</dd><dt>17D_MP8</dt><dd>34.6177079961713</dd><dt>17D_MP9</dt><dd>34.7169801607932</dd><dt>17D_MP10</dt><dd>34.3935669718346</dd><dt>17D_MP11</dt><dd>34.4872273844761</dd><dt>17D_MP12</dt><dd>35.8855409852696</dd><dt>15D_MP1</dt><dd>31.4610669622702</dd><dt>15D_MP2</dt><dd>30.0029487479584</dd><dt>15D_MP3</dt><dd>29.744411825829</dd><dt>6D_MP13</dt><dd>68.3948984647558</dd><dt>6D_MP14</dt><dd>50.6152161684977</dd><dt>6D_MP15</dt><dd>65.3465461644283</dd><dt>6D_MP16</dt><dd>61.4979528466198</dd><dt>6D_MP17</dt><dd>59.3102858705195</dd><dt>6D_MP18</dt><dd>67.296457475466</dd><dt>12D_MP_L13</dt><dd>31.0701762727506</dd><dt>12D_MP_L14</dt><dd>35.951189717604</dd><dt>12D_MB_L1</dt><dd>35.0598345159783</dd><dt>12D_MB_L2</dt><dd>36.3194693732443</dd><dt>12D_MB_S1</dt><dd>46.475378774337</dd><dt>1D_MT1</dt><dd>13.4304674882495</dd><dt>1D_MT2</dt><dd>16.909985813105</dd><dt>1D_MT3</dt><dd>30.5695486395602</dd><dt>1D_MT4</dt><dd>27.9935507460761</dd><dt>6D_MT1</dt><dd>55.9229839666055</dd><dt>6D_MT2</dt><dd>49.0892953918897</dd><dt>6D_MT3</dt><dd>53.8196466777058</dd><dt>6D_MT4</dt><dd>52.2237215444473</dd><dt>6D_MT5</dt><dd>52.4056976141238</dd><dt>6D_MT6</dt><dd>49.0644794158466</dd><dt>9D_MT1</dt><dd>18.7867804713222</dd><dt>9D_MT2</dt><dd>21.4328452399734</dd><dt>9D_MT3</dt><dd>24.7323669911937</dd><dt>9D_MT4</dt><dd>22.9305075220569</dd><dt>10D_MT1</dt><dd>30.9252224777221</dd><dt>10D_MT2</dt><dd>29.6862486197508</dd><dt>20T_MP1</dt><dd>31.7873430841715</dd><dt>20T_MP2</dt><dd>27.1356382942678</dd><dt>20T_MP3</dt><dd>30.6110833166726</dd><dt>21T_MP1</dt><dd>31.3043985115132</dd><dt>21T_MP2</dt><dd>27.2170709071935</dd><dt>21T_MP3</dt><dd>28.8421612872075</dd><dt>23T_MP1</dt><dd>6.63544545332065</dd><dt>23T_MP2</dt><dd>6.53450832134877</dd><dt>23T_MP3</dt><dd>5.70600465136799</dd><dt>23T_MP4</dt><dd>6.65789217400023</dd><dt>23T_MP5</dt><dd>5.83280917178043</dd><dt>23T_MP6</dt><dd>6.49499364719405</dd><dt>22T_MB1</dt><dd>23.8573186549708</dd><dt>22T_MB2</dt><dd>22.7051004787074</dd><dt>22T_MB3</dt><dd>22.0782460833516</dd><dt>23T_MB1</dt><dd>8.14827691104255</dd><dt>23T_MB2</dt><dd>9.35206191173942</dd><dt>23T_MB3</dt><dd>5.84542874320067</dd><dt>23T_MB4</dt><dd>3.40346058830455</dd><dt>23T_MB5</dt><dd>6.34558193024398</dd><dt>23T_MB6</dt><dd>9.43950735503058</dd><dt>26T_MB1</dt><dd>18.2805195126018</dd><dt>26T_MB2</dt><dd>19.8498937346206</dd><dt>26T_MB3</dt><dd>18.9411672699363</dd><dt>27T_MB1</dt><dd>26.2758460320851</dd><dt>27T_MB2</dt><dd>26.0738492036812</dd><dt>27T_MB3</dt><dd>10.5635570786095</dd><dt>23T_MT1</dt><dd>8.48724720380568</dd><dt>23T_MT3</dt><dd>7.07650249592736</dd><dt>23T_MT4</dt><dd>7.7659219881159</dd><dt>23T_MT5</dt><dd>7.87104175785844</dd><dt>23T_MT6</dt><dd>8.25949316517963</dd><dt>24T_MT1</dt><dd>14.1486025366322</dd><dt>24T_MT2</dt><dd>14.0580561439892</dd><dt>24T_MT3</dt><dd>13.0883750333055</dd><dt>25T_MT1</dt><dd>32.6679579012367</dd><dt>25T_MT2</dt><dd>34.2026839226104</dd><dt>25T_MT3</dt><dd>28.2596750137373</dd><dt>25T_MT4</dt><dd>30.4772707270813</dd><dt>27T_MT1</dt><dd>29.0166586630896</dd><dt>27T_MT2</dt><dd>31.4314728687873</dd><dt>27T_MT3</dt><dd>41.0443453910451</dd><dt>13E_MP1</dt><dd>90.2578314064537</dd><dt>13E_MP2</dt><dd>46.2432984789885</dd><dt>13E_MP3</dt><dd>55.1015015102356</dd><dt>10F_FSM1</dt><dd>47.487153103068</dd><dt>10F_FSM2</dt><dd>45.9265548942488</dd><dt>10F_FSM3</dt><dd>79.844463373414</dd><dt>10F_FSM4</dt><dd>70.5346481517547</dd><dt>13F_MP1</dt><dd>26.7575918485248</dd><dt>13F_MP2</dt><dd>28.0588538250718</dd><dt>13F_MP3</dt><dd>27.8545712833297</dd><dt>33A_ASM1</dt><dd>9.79664038904024</dd><dt>33A_ASM2</dt><dd>18.9281736434276</dd><dt>33A_ASM3</dt><dd>23.5307218233124</dd><dt>33A_ASM4</dt><dd>23.898152309159</dd><dt>33A_ASM5</dt><dd>14.4874097651953</dd><dt>33A_ASM6</dt><dd>21.3903589517933</dd><dt>33A_ASM7</dt><dd>12.9599409477473</dd><dt>33A_ASM8</dt><dd>24.5042984623553</dd><dt>33A_ASM9</dt><dd>10.5336495346215</dd><dt>33A_ASM10</dt><dd>22.1316927435164</dd><dt>33A_ASM11</dt><dd>16.0548192957112</dd><dt>33A_ASM12</dt><dd>12.2557474019298</dd><dt>33A_ASM13</dt><dd>10.5009790463162</dd><dt>33A_ASM14</dt><dd>8.78740153933491</dd><dt>33A_ASM15</dt><dd>11.679787401453</dd><dt>33A_ASM16</dt><dd>18.5336428654615</dd><dt>33A_ASM17</dt><dd>12.9707515585263</dd><dt>33A_ASM18</dt><dd>7.62193341651076</dd><dt>33A_ASM19</dt><dd>8.00386386528096</dd><dt>33A_ASM20</dt><dd>5.43818259873759</dd><dt>33A_ASM21</dt><dd>11.4429517749574</dd><dt>33A_ASM22</dt><dd>9.98296045671065</dd><dt>33A_ASM23</dt><dd>13.7826279659579</dd><dt>33A_ASM24</dt><dd>6.71493902918058</dd><dt>13A_ASM1</dt><dd>73.7403887638214</dd><dt>13A_ASM2</dt><dd>127.967926317558</dd><dt>13A_ASM3</dt><dd>182.004526146286</dd><dt>20A_MB1</dt><dd>41.3643421739757</dd><dt>20A_MB2</dt><dd>31.4581349595499</dd><dt>20A_MB3</dt><dd>37.2895939963792</dd><dt>20A_MB4</dt><dd>37.4745794370968</dd><dt>46A_MB1</dt><dd>26.7570197542628</dd><dt>46A_MB2</dt><dd>27.0706788503666</dd><dt>46A_MB3</dt><dd>24.5710053828807</dd><dt>47A_MB1</dt><dd>10.8177531671876</dd><dt>47A_MB2</dt><dd>10.9111460102838</dd><dt>49A_MB1</dt><dd>22.9030782483381</dd><dt>49A_MB2</dt><dd>29.5724726528281</dd><dt>49A_MB3</dt><dd>35.3414097991295</dd><dt>49A_MB4</dt><dd>30.9629495607606</dd><dt>49A_MB5</dt><dd>22.3999152451415</dd><dt>49A_MB6</dt><dd>26.4413746334932</dd><dt>49A_MB7</dt><dd>25.4615817387699</dd><dt>49A_MB8</dt><dd>24.1281404875891</dd><dt>50A_MB1</dt><dd>35.4508183363983</dd><dt>50A_MB2</dt><dd>36.3715902892636</dd><dt>52A_MB1</dt><dd>25.7499218043191</dd><dt>52A_MB2</dt><dd>33.2863856602251</dd><dt>52A_MB3</dt><dd>24.1662228096598</dd><dt>52A_MB4</dt><dd>21.8524738214392</dd><dt>52A_MB5</dt><dd>20.6393389496979</dd><dt>52A_MB6</dt><dd>20.4121136420164</dd><dt>52A_MB7</dt><dd>23.6061477672216</dd><dt>52A_MB8</dt><dd>24.5429996583356</dd><dt>52A_MB9</dt><dd>17.8793239733504</dd><dt>52A_MB10</dt><dd>17.7186329629681</dd><dt>54A_MB1</dt><dd>16.9959546056209</dd><dt>54A_MB2</dt><dd>14.126901644612</dd><dt>60A_MB1</dt><dd>28.1161524026233</dd><dt>60A_MB2</dt><dd>29.8542319534534</dd><dt>43C_MB1</dt><dd>21.6138311150879</dd><dt>43C_MB2</dt><dd>15.331236265512</dd><dt>39C_MB1</dt><dd>32.3180227520338</dd><dt>39C_MB2</dt><dd>31.7458320476652</dd><dt>39C_MB3</dt><dd>35.8907188380512</dd><dt>41C_MB1</dt><dd>29.8781580092167</dd><dt>41C_MB2</dt><dd>33.2938341027062</dd><dt>45C_MB1</dt><dd>46.9158119690853</dd><dt>45C_MB2</dt><dd>41.5554560348851</dd><dt>45C_MB3</dt><dd>40.4095285607626</dd><dt>45C_MB4</dt><dd>41.9124285979156</dd><dt>45C_MB5</dt><dd>41.8868337428935</dd><dt>45C_MB6</dt><dd>40.7098746177544</dd><dt>45C_MB7</dt><dd>35.3559930913833</dd><dt>45C_MB8</dt><dd>39.5574063429569</dd><dt>45C_MB9</dt><dd>38.3643327581293</dd><dt>45C_MB10</dt><dd>33.3120328995113</dd><dt>45C_MB11</dt><dd>36.319367263624</dd><dt>45C_MB12</dt><dd>34.718296631346</dd><dt>45C_MB13</dt><dd>33.680008917751</dd><dt>45C_MB14</dt><dd>39.1882285117756</dd><dt>45C_MB15</dt><dd>35.5675216521024</dd><dt>45C_MB16</dt><dd>35.8765334197344</dd><dt>45C_MB17</dt><dd>37.1997953829792</dd><dt>45C_MB18</dt><dd>38.2375784337212</dd><dt>45C_MB19</dt><dd>37.2154810021172</dd><dt>45C_MB20</dt><dd>34.9774563227847</dd><dt>45C_MB21</dt><dd>⋯</dd><dt>45C_MB22</dt><dd>33.4136211033911</dd><dt>45C_MB23</dt><dd>33.1012381338913</dd><dt>45C_MB24</dt><dd>37.0977962614912</dd><dt>45C_MB25</dt><dd>37.8890526171863</dd><dt>45C_MB26</dt><dd>34.0076675954539</dd><dt>45C_MB27</dt><dd>31.3961820177128</dd><dt>45C_MB28</dt><dd>34.0619845544383</dd><dt>45C_MB29</dt><dd>25.0684990691607</dd><dt>45C_MB30</dt><dd>23.7711304375063</dd><dt>45C_MB31</dt><dd>14.7669726691549</dd><dt>45C_MB32</dt><dd>14.5461878983089</dd><dt>45C_MB33</dt><dd>15.9779623051804</dd><dt>45C_MB34</dt><dd>32.4309602586598</dd><dt>45C_MB35</dt><dd>34.484508549824</dd><dt>45C_MB36</dt><dd>33.0985408996271</dd><dt>45C_MB37</dt><dd>33.7358215115402</dd><dt>45C_MB38</dt><dd>31.6987533399963</dd><dt>45C_MB39</dt><dd>29.2913719127154</dd><dt>45C_MB40</dt><dd>12.6735584803044</dd><dt>45C_MB41</dt><dd>16.1998436345792</dd><dt>45C_MB42</dt><dd>24.5589903922586</dd><dt>45C_MB43</dt><dd>24.8900020522051</dd><dt>45C_MB44</dt><dd>88.9665294285807</dd><dt>45C_MB45</dt><dd>95.7305010252019</dd><dt>53C_MB1</dt><dd>153.081510808139</dd><dt>53C_MB2</dt><dd>150.208710019345</dd><dt>24A_MB1</dt><dd>111.930803714831</dd><dt>24A_MB2</dt><dd>96.0909431606492</dd><dt>24A_MB3</dt><dd>96.4896817168222</dd><dt>55C_MB1</dt><dd>107.981526753178</dd><dt>55C_MB2</dt><dd>96.7178094704923</dd><dt>55C_MB3</dt><dd>99.4187484583531</dd><dt>58C_MB1</dt><dd>130.079744539044</dd><dt>58C_MB2</dt><dd>129.042736227866</dd><dt>58C_MB3</dt><dd>104.192581913444</dd><dt>47A_MT1</dt><dd>96.0689507730658</dd><dt>47A_MT2</dt><dd>116.114921104334</dd><dt>40C_MT1</dt><dd>125.082957221629</dd><dt>40C_MT2</dt><dd>33.1320248330419</dd><dt>1D_hPSC1</dt><dd>23.9976028987243</dd><dt>1D_hPSC2</dt><dd>32.7367065482365</dd><dt>1D_hPSC3</dt><dd>30.5480142074017</dd><dt>1D_hPSC4</dt><dd>31.7135491748537</dd><dt>6D_hPSC1</dt><dd>29.8107983813264</dd><dt>6D_hPSC2</dt><dd>7.55222824094893</dd><dt>6D_hPSC3</dt><dd>8.48919061318245</dd><dt>6D_hPSC4</dt><dd>4.85390635997132</dd><dt>6D_hPSC5</dt><dd>5.47305203759933</dd><dt>6D_hPSC6</dt><dd>4.6791562215208</dd><dt>12D_hPSC_L1</dt><dd>24.3713824281096</dd><dt>12D_hPSC_L2</dt><dd>23.4792779098302</dd><dt>12D_hPSC_S1</dt><dd>22.0588365231203</dd><dt>12D_hPSC_S2</dt><dd>29.1703319492619</dd><dt>12D_hPSC_T1</dt><dd>31.9266875525897</dd><dt>12D_hPSC_T2</dt><dd>42.8511193493638</dd><dt>20T_FB1</dt><dd>46.1184193786418</dd><dt>20T_FB2</dt><dd>24.51860056616</dd><dt>20T_FB3</dt><dd>43.5487232447532</dd><dt>21T_FB1</dt><dd>45.0879537848959</dd><dt>21T_FB2</dt><dd>48.1768665316498</dd><dt>21T_FB3</dt><dd>17.9196843007764</dd><dt>23T_FB1</dt><dd>16.6532935672869</dd><dt>23T_FB2</dt><dd>6.81650957401593</dd><dt>23T_FB4</dt><dd>4.58453207091777</dd><dt>23T_FB5</dt><dd>13.5397473368044</dd><dt>23T_FB6</dt><dd>10.1072706290296</dd><dt>24T_FB1</dt><dd>16.4696634551428</dd><dt>24T_FB2</dt><dd>20.6091072421478</dd><dt>24T_FB3</dt><dd>14.0210663300138</dd><dt>25T_FB1</dt><dd>21.0569244789944</dd><dt>25T_FB2</dt><dd>1.51691054976615</dd><dt>27T_FB1</dt><dd>16.0918706288015</dd><dt>27T_FB2</dt><dd>10.8591187041427</dd><dt>27T_FB3</dt><dd>23.1485996216291</dd><dt>27T_FB4</dt><dd>10.3829463773978</dd><dt>27T_FB5</dt><dd>8.57979194249676</dd><dt>27T_FB6</dt><dd>17.1404811720108</dd><dt>34A_T1_01</dt><dd>10.8275422481418</dd><dt>34A_T1_02</dt><dd>5.65105727896942</dd><dt>34A_T1_03</dt><dd>18.437685976808</dd><dt>34A_T1_04</dt><dd>10.761596294072</dd><dt>34A_T1_05</dt><dd>1.27128096944555</dd><dt>34A_T1_06</dt><dd>4.02522327269458</dd><dt>34A_T1_07</dt><dd>0.0630186930773808</dd><dt>34A_T1_08</dt><dd>3.71850648265974</dd><dt>34A_T1_09</dt><dd>17.1978883114971</dd><dt>34A_T2_01</dt><dd>10.9088591674239</dd><dt>34A_T2_02</dt><dd>5.03954054577879</dd><dt>34A_T2_03</dt><dd>16.0489753812818</dd><dt>34A_T2_04</dt><dd>16.9601434595806</dd><dt>34A_T2_05</dt><dd>11.2659474168006</dd><dt>34A_T2_06</dt><dd>11.4531431679929</dd><dt>34A_T2_07</dt><dd>4.04677731479566</dd><dt>34A_T2_08</dt><dd>10.7441033419022</dd><dt>34A_T2_09</dt><dd>22.1739983626036</dd><dt>61A_T1_01</dt><dd>19.745685509738</dd><dt>61A_T1_02</dt><dd>19.9101911148614</dd><dt>61A_T1_03</dt><dd>3.89417188562177</dd><dt>61A_T1_04</dt><dd>18.8612705176428</dd><dt>61A_T1_05</dt><dd>11.9207851456446</dd><dt>61A_T1_06</dt><dd>14.7478412428408</dd><dt>61A_T1_07</dt><dd>12.1705013495256</dd><dt>61A_T1_08</dt><dd>12.6454370241818</dd><dt>61A_T1_09</dt><dd>16.536188834033</dd><dt>61A_T1_10</dt><dd>20.8748135302508</dd><dt>61A_T1_11</dt><dd>16.6384767229074</dd><dt>61A_T1_12</dt><dd>8.24231425466241</dd><dt>61A_T1_13</dt><dd>9.44784086468182</dd><dt>61A_T1_14</dt><dd>12.2091184544951</dd><dt>61A_T1_15</dt><dd>3.49656295332976</dd><dt>61A_T1_16</dt><dd>7.42462303724217</dd><dt>61A_T1_17</dt><dd>8.4161786156803</dd><dt>61A_T1_18</dt><dd>13.5584830295919</dd><dt>61A_T1_19</dt><dd>11.5086209161179</dd><dt>61A_T1_20</dt><dd>16.6933206455822</dd><dt>61A_T1_21</dt><dd>12.0225848594631</dd><dt>61A_T1_22</dt><dd>10.2848619680939</dd><dt>61A_T1_23</dt><dd>12.5493118572776</dd><dt>61A_T1_24</dt><dd>23.811226526736</dd><dt>61A_T1_25</dt><dd>1.38066999871647</dd><dt>61A_T1_26</dt><dd>3.4705049992757</dd><dt>61A_T1_27</dt><dd>16.6888383712729</dd><dt>61A_T1_28</dt><dd>14.1797045357241</dd><dt>61A_T1_29</dt><dd>12.7426878515125</dd><dt>61A_T1_30</dt><dd>28.7309238580703</dd><dt>61A_T1_31</dt><dd>26.0267887658655</dd><dt>61A_T1_32</dt><dd>18.3883137382739</dd><dt>61A_T1_33</dt><dd>11.6732379517131</dd><dt>61A_T1_34</dt><dd>6.98539549733333</dd><dt>61A_T1_35</dt><dd>7.95589032636088</dd><dt>61A_T1_36</dt><dd>6.92408508797919</dd><dt>61A_T1_37</dt><dd>19.8148312994596</dd><dt>61A_T1_38</dt><dd>21.4273585068528</dd><dt>61A_T1_39</dt><dd>4.22736916813507</dd><dt>61A_T2_01</dt><dd>16.2506457742085</dd><dt>61A_T2_02</dt><dd>13.8435669944343</dd><dt>61A_T2_03</dt><dd>11.5737707781941</dd><dt>61A_T2_04</dt><dd>14.5665773066313</dd><dt>61A_T2_05</dt><dd>27.0177926001262</dd><dt>61A_T2_06</dt><dd>17.9627910401243</dd><dt>61A_T2_07</dt><dd>19.6209899129508</dd><dt>61A_T2_08</dt><dd>10.4062271385139</dd><dt>61A_T2_09</dt><dd>10.4119548483204</dd><dt>61A_T2_10</dt><dd>21.988064865681</dd><dt>61A_T2_11</dt><dd>6.43600974121964</dd><dt>61A_T2_12</dt><dd>11.697093078461</dd><dt>61A_T2_13</dt><dd>3.96236674336741</dd><dt>61A_T2_14</dt><dd>10.8822831066951</dd><dt>61A_T2_15</dt><dd>9.42435021723127</dd><dt>61A_T2_16</dt><dd>5.53176485891603</dd><dt>61A_T2_17</dt><dd>19.0402067057538</dd><dt>61A_T2_18</dt><dd>23.2087163808091</dd><dt>61A_T2_19</dt><dd>28.8343430946285</dd><dt>61A_T2_20</dt><dd>19.9748663816762</dd><dt>61A_T2_21</dt><dd>32.2222043209976</dd><dt>61A_T2_22</dt><dd>8.35412985228452</dd><dt>61A_T2_23</dt><dd>22.3126916657899</dd><dt>61A_T2_24</dt><dd>14.6136980154382</dd><dt>61A_T2_25</dt><dd>45.3261218808136</dd><dt>61A_T2_26</dt><dd>31.2427300768951</dd><dt>61A_T2_27</dt><dd>38.8890302635374</dd><dt>61A_T2_28</dt><dd>43.9039504173925</dd><dt>61A_T2_29</dt><dd>48.2943803060845</dd><dt>61A_T2_30</dt><dd>45.8171073386205</dd><dt>61A_T2_31</dt><dd>45.0732763774694</dd><dt>61A_T2_32</dt><dd>42.0720302682424</dd><dt>61A_T2_33</dt><dd>42.0445841162909</dd><dt>61A_T2_34</dt><dd>47.6061776048562</dd><dt>61A_T2_35</dt><dd>31.4158078788709</dd><dt>61A_T2_36</dt><dd>49.7483629296569</dd><dt>61A_T2_37</dt><dd>52.646255891235</dd><dt>61A_T2_38</dt><dd>28.0365308041601</dd><dt>61A_T2_39</dt><dd>34.2943030218177</dd><dt>61A_T2_40</dt><dd>40.6255349730127</dd><dt>61A_T2_41</dt><dd>44.49233371399</dd><dt>62F_FSM10</dt><dd>42.2620884874865</dd><dt>62F_FSM11</dt><dd>44.3298000600057</dd><dt>62F_FSM12</dt><dd>42.1242007056031</dd><dt>62F_FSM13</dt><dd>47.9983435209272</dd><dt>62F_FSM14</dt><dd>24.6582082243537</dd><dt>62F_FSM15</dt><dd>38.0400101398765</dd><dt>62F_FSM16</dt><dd>45.000661814449</dd><dt>62F_FSM17</dt><dd>40.4524664732964</dd><dt>62F_FSM18</dt><dd>49.3710218183644</dd><dt>62F_FSM19</dt><dd>41.4731423052795</dd><dt>62F_FSM1</dt><dd>42.1985218381505</dd><dt>62F_FSM20</dt><dd>40.5517399384397</dd><dt>62F_FSM21</dt><dd>39.3666717715601</dd><dt>62F_FSM22</dt><dd>48.8582692445625</dd><dt>62F_FSM23</dt><dd>50.4679781320838</dd><dt>62F_FSM24</dt><dd>45.9006554557865</dd><dt>62F_FSM25</dt><dd>39.5481953573874</dd><dt>62F_FSM26</dt><dd>41.6702737929632</dd><dt>62F_FSM27</dt><dd>61.2650166070417</dd><dt>62F_FSM28</dt><dd>62.9361030316772</dd><dt>62F_FSM29</dt><dd>59.4763106616067</dd><dt>62F_FSM2</dt><dd>50.6421572130331</dd><dt>62F_FSM30</dt><dd>45.7596779215301</dd><dt>62F_FSM31</dt><dd>37.6599672796191</dd><dt>62F_FSM32</dt><dd>47.5913019112133</dd></dl>




```R
keepersMT1 <- rowSums(cpmMT1>0)>=1
DGE_MT1.filt <- DGE_MT1[keepersMT1,]
dim(DGE_MT1.filt)
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>57027</li><li>418</li></ol>




```R
log2.cpm_MT1 <- cpm(DGE_MT1.filt, log=TRUE)
DGE_MT1.filt.norm <- calcNormFactors(DGE_MT1.filt, method="TMM")
log2.cpm_MT1.filt.norm <- cpm(DGE_MT1.filt.norm, log=TRUE)
```


```R
groupMT1 <- factor(c("DMP","DMP","DMP","DMP","DMP","DMP","DMP","DMP","DMP","DMP","DMP","DMP","DMP","DMP","DMP","DMP","DMP","DMP","DMP","DMP","DMP","DMP","DMP","DMP","DMP","DMP","DMP","DMP","DMP","DMP","DMP","DMP","DMP","DMP","DMT","DMT","DMT","DMT","DMT","DMT","DMT","DMT","DMT","DMT","DMT","DMT","DMT","DMT","DMT","DMT","DMT","DMT","DMT","DMT","DMT","DMT","DMT","DMT","DMT","DMT","DMT","TMP","TMP","TMP","TMP","TMP","TMP","TMP","TMP","TMP","TMP","TMP","TMP","TMP","TMP","TMP","TMP","TMP","TMP","TMP","TMP","TMP","TMP","TMP","TMP","TMP","TMP","TMP","TMT","TMT","TMT","TMT","TMT","TMT","TMT","TMT","TMT","TMT","TMT","TMT","TMT","TMT","TMT","FE","FE","FE","FE","FE","FE","FE","FE","FE","FE","Biopsy","Biopsy","Biopsy","Biopsy","Biopsy","Biopsy","Biopsy","Biopsy","Biopsy","Biopsy","Biopsy","Biopsy","Biopsy","Biopsy","Biopsy","Biopsy","Biopsy","Biopsy","Biopsy","Biopsy","Biopsy","Biopsy","Biopsy","Biopsy","SAT","SAT","SAT","PMB","PMB","PMB","PMB","PMB","PMB","PMB","PMB","PMB","PMB","PMB","PMB","PMB","PMB","PMB","PMB","PMB","PMB","PMB","PMB","PMB","PMB","PMB","PMB","PMB","PMB","PMB","PMB","PMB","PMB","PMB","PMB","PMB","PMB","PMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","CMB","PMT","PMT","CMT","CMT","hPSC","hPSC","hPSC","hPSC","hPSC","hPSC","hPSC","hPSC","hPSC","hPSC","hPSC","hPSC","hPSC","hPSC","hPSC","hPSC","FB","FB","FB","FB","FB","FB","FB","FB","FB","FB","FB","FB","FB","FB","FB","FB","FB","FB","FB","FB","FB","FB","MF","MF","MF","MF","MF","MF","MF","MF","MF","MF","MF","MF","MF","MF","MF","MF","MF","MF","MF","MF","MF","MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", "MF", 	"MF", 	"MF", 	"MF", 	"MF", 	"MF", 	"MF", 	"MF", 	"MF", 	"MF", 	"MF", 	"MF", 	"MF", 	"MF", 	"MF", 	"MF", 	"MF", 	"MF", 	"MF", 	"MF", 	"MF", 	"MF", 	"MF", 	"MF", 	"MF", 	"MF", 	"MF", 	"F",	"F",	"F",	"F",	"F",	"F",	"F",	"F",	"F",	"F",	"F",	"F",	"F",	"F",	"F",	"F",	"F",	"F",	"F",	"F",	"F",	"F",	"F",	"F",	"F",	"F",	"F",	"F",	"F",	"F",	"F",	"F",	"F",	"F",	"F", "3D","3D","3D","3D","3D","3D","3D"))
length(groupMT1)
```


418



```R
samplelabels1 <- colnames(log2.cpm_MT1.filt.norm)
```


```R
print(samplelabels1)
```

      [1] "1D_MP1"       "1D_MP2"       "1D_MP3"       "1D_MP4"       "9D_MP1"      
      [6] "9D_MP2"       "9D_MP3"       "9D_MP4"       "10D_MP1"      "10D_MP2"     
     [11] "12D_MP_L9"    "12D_MP_L10"   "12D_MP_L11"   "12D_MP_L12"   "13D_MP1"     
     [16] "13D_MP2"      "13D_MP3"      "13D_MP4"      "13D_MP5"      "17D_MP1"     
     [21] "17D_MP2"      "17D_MP3"      "17D_MP4"      "17D_MP5"      "17D_MP6"     
     [26] "17D_MP7"      "17D_MP8"      "17D_MP9"      "17D_MP10"     "17D_MP11"    
     [31] "17D_MP12"     "15D_MP1"      "15D_MP2"      "15D_MP3"      "6D_MP13"     
     [36] "6D_MP14"      "6D_MP15"      "6D_MP16"      "6D_MP17"      "6D_MP18"     
     [41] "12D_MP_L13"   "12D_MP_L14"   "12D_MB_L1"    "12D_MB_L2"    "12D_MB_S1"   
     [46] "1D_MT1"       "1D_MT2"       "1D_MT3"       "1D_MT4"       "6D_MT1"      
     [51] "6D_MT2"       "6D_MT3"       "6D_MT4"       "6D_MT5"       "6D_MT6"      
     [56] "9D_MT1"       "9D_MT2"       "9D_MT3"       "9D_MT4"       "10D_MT1"     
     [61] "10D_MT2"      "20T_MP1"      "20T_MP2"      "20T_MP3"      "21T_MP1"     
     [66] "21T_MP2"      "21T_MP3"      "23T_MP1"      "23T_MP2"      "23T_MP3"     
     [71] "23T_MP4"      "23T_MP5"      "23T_MP6"      "22T_MB1"      "22T_MB2"     
     [76] "22T_MB3"      "23T_MB1"      "23T_MB2"      "23T_MB3"      "23T_MB4"     
     [81] "23T_MB5"      "23T_MB6"      "26T_MB1"      "26T_MB2"      "26T_MB3"     
     [86] "27T_MB1"      "27T_MB2"      "27T_MB3"      "23T_MT1"      "23T_MT3"     
     [91] "23T_MT4"      "23T_MT5"      "23T_MT6"      "24T_MT1"      "24T_MT2"     
     [96] "24T_MT3"      "25T_MT1"      "25T_MT2"      "25T_MT3"      "25T_MT4"     
    [101] "27T_MT1"      "27T_MT2"      "27T_MT3"      "13E_MP1"      "13E_MP2"     
    [106] "13E_MP3"      "10F_FSM1"     "10F_FSM2"     "10F_FSM3"     "10F_FSM4"    
    [111] "13F_MP1"      "13F_MP2"      "13F_MP3"      "33A_ASM1"     "33A_ASM2"    
    [116] "33A_ASM3"     "33A_ASM4"     "33A_ASM5"     "33A_ASM6"     "33A_ASM7"    
    [121] "33A_ASM8"     "33A_ASM9"     "33A_ASM10"    "33A_ASM11"    "33A_ASM12"   
    [126] "33A_ASM13"    "33A_ASM14"    "33A_ASM15"    "33A_ASM16"    "33A_ASM17"   
    [131] "33A_ASM18"    "33A_ASM19"    "33A_ASM20"    "33A_ASM21"    "33A_ASM22"   
    [136] "33A_ASM23"    "33A_ASM24"    "13A_ASM1"     "13A_ASM2"     "13A_ASM3"    
    [141] "20A_MB1"      "20A_MB2"      "20A_MB3"      "20A_MB4"      "46A_MB1"     
    [146] "46A_MB2"      "46A_MB3"      "47A_MB1"      "47A_MB2"      "49A_MB1"     
    [151] "49A_MB2"      "49A_MB3"      "49A_MB4"      "49A_MB5"      "49A_MB6"     
    [156] "49A_MB7"      "49A_MB8"      "50A_MB1"      "50A_MB2"      "52A_MB1"     
    [161] "52A_MB2"      "52A_MB3"      "52A_MB4"      "52A_MB5"      "52A_MB6"     
    [166] "52A_MB7"      "52A_MB8"      "52A_MB9"      "52A_MB10"     "54A_MB1"     
    [171] "54A_MB2"      "60A_MB1"      "60A_MB2"      "43C_MB1"      "43C_MB2"     
    [176] "39C_MB1"      "39C_MB2"      "39C_MB3"      "41C_MB1"      "41C_MB2"     
    [181] "45C_MB1"      "45C_MB2"      "45C_MB3"      "45C_MB4"      "45C_MB5"     
    [186] "45C_MB6"      "45C_MB7"      "45C_MB8"      "45C_MB9"      "45C_MB10"    
    [191] "45C_MB11"     "45C_MB12"     "45C_MB13"     "45C_MB14"     "45C_MB15"    
    [196] "45C_MB16"     "45C_MB17"     "45C_MB18"     "45C_MB19"     "45C_MB20"    
    [201] "45C_MB21"     "45C_MB22"     "45C_MB23"     "45C_MB24"     "45C_MB25"    
    [206] "45C_MB26"     "45C_MB27"     "45C_MB28"     "45C_MB29"     "45C_MB30"    
    [211] "45C_MB31"     "45C_MB32"     "45C_MB33"     "45C_MB34"     "45C_MB35"    
    [216] "45C_MB36"     "45C_MB37"     "45C_MB38"     "45C_MB39"     "45C_MB40"    
    [221] "45C_MB41"     "45C_MB42"     "45C_MB43"     "45C_MB44"     "45C_MB45"    
    [226] "53C_MB1"      "53C_MB2"      "24A_MB1"      "24A_MB2"      "24A_MB3"     
    [231] "55C_MB1"      "55C_MB2"      "55C_MB3"      "58C_MB1"      "58C_MB2"     
    [236] "58C_MB3"      "47A_MT1"      "47A_MT2"      "40C_MT1"      "40C_MT2"     
    [241] "1D_hPSC1"     "1D_hPSC2"     "1D_hPSC3"     "1D_hPSC4"     "6D_hPSC1"    
    [246] "6D_hPSC2"     "6D_hPSC3"     "6D_hPSC4"     "6D_hPSC5"     "6D_hPSC6"    
    [251] "12D_hPSC_L1"  "12D_hPSC_L2"  "12D_hPSC_S1"  "12D_hPSC_S2"  "12D_hPSC_T1" 
    [256] "12D_hPSC_T2"  "20T_FB1"      "20T_FB2"      "20T_FB3"      "21T_FB1"     
    [261] "21T_FB2"      "21T_FB3"      "23T_FB1"      "23T_FB2"      "23T_FB4"     
    [266] "23T_FB5"      "23T_FB6"      "24T_FB1"      "24T_FB2"      "24T_FB3"     
    [271] "25T_FB1"      "25T_FB2"      "27T_FB1"      "27T_FB2"      "27T_FB3"     
    [276] "27T_FB4"      "27T_FB5"      "27T_FB6"      "34A_T1_01"    "34A_T1_02"   
    [281] "34A_T1_03"    "34A_T1_04"    "34A_T1_05"    "34A_T1_06"    "34A_T1_07"   
    [286] "34A_T1_08"    "34A_T1_09"    "34A_T2_01"    "34A_T2_02"    "34A_T2_03"   
    [291] "34A_T2_04"    "34A_T2_05"    "34A_T2_06"    "34A_T2_07"    "34A_T2_08"   
    [296] "34A_T2_09"    "61A_T1_01"    "61A_T1_02"    "61A_T1_03"    "61A_T1_04"   
    [301] "61A_T1_05"    "61A_T1_06"    "61A_T1_07"    "61A_T1_08"    "61A_T1_09"   
    [306] "61A_T1_10"    "61A_T1_11"    "61A_T1_12"    "61A_T1_13"    "61A_T1_14"   
    [311] "61A_T1_15"    "61A_T1_16"    "61A_T1_17"    "61A_T1_18"    "61A_T1_19"   
    [316] "61A_T1_20"    "61A_T1_21"    "61A_T1_22"    "61A_T1_23"    "61A_T1_24"   
    [321] "61A_T1_25"    "61A_T1_26"    "61A_T1_27"    "61A_T1_28"    "61A_T1_29"   
    [326] "61A_T1_30"    "61A_T1_31"    "61A_T1_32"    "61A_T1_33"    "61A_T1_34"   
    [331] "61A_T1_35"    "61A_T1_36"    "61A_T1_37"    "61A_T1_38"    "61A_T1_39"   
    [336] "61A_T2_01"    "61A_T2_02"    "61A_T2_03"    "61A_T2_04"    "61A_T2_05"   
    [341] "61A_T2_06"    "61A_T2_07"    "61A_T2_08"    "61A_T2_09"    "61A_T2_10"   
    [346] "61A_T2_11"    "61A_T2_12"    "61A_T2_13"    "61A_T2_14"    "61A_T2_15"   
    [351] "61A_T2_16"    "61A_T2_17"    "61A_T2_18"    "61A_T2_19"    "61A_T2_20"   
    [356] "61A_T2_21"    "61A_T2_22"    "61A_T2_23"    "61A_T2_24"    "61A_T2_25"   
    [361] "61A_T2_26"    "61A_T2_27"    "61A_T2_28"    "61A_T2_29"    "61A_T2_30"   
    [366] "61A_T2_31"    "61A_T2_32"    "61A_T2_33"    "61A_T2_34"    "61A_T2_35"   
    [371] "61A_T2_36"    "61A_T2_37"    "61A_T2_38"    "61A_T2_39"    "61A_T2_40"   
    [376] "61A_T2_41"    "62F_FSM10"    "62F_FSM11"    "62F_FSM12"    "62F_FSM13"   
    [381] "62F_FSM14"    "62F_FSM15"    "62F_FSM16"    "62F_FSM17"    "62F_FSM18"   
    [386] "62F_FSM19"    "62F_FSM1"     "62F_FSM20"    "62F_FSM21"    "62F_FSM22"   
    [391] "62F_FSM23"    "62F_FSM24"    "62F_FSM25"    "62F_FSM26"    "62F_FSM27"   
    [396] "62F_FSM28"    "62F_FSM29"    "62F_FSM2"     "62F_FSM30"    "62F_FSM31"   
    [401] "62F_FSM32"    "62F_FSM33"    "62F_FSM34"    "62F_FSM35"    "62F_FSM3"    
    [406] "62F_FSM4"     "62F_FSM5"     "62F_FSM6"     "62F_FSM7"     "62F_FSM8"    
    [411] "62F_FSM9"     "63_3D_04w_01" "63_3D_04w_02" "63_3D_04w_03" "63_3D_08w_01"
    [416] "63_3D_08w_02" "63_3D_16w_01" "63_3D_16w_02"



```R
#hierarchical clustering: distance matrix 
distance <- dist(t(log2.cpm_MT1.filt.norm), method = "euclidean") 
clusters <- hclust(distance, method = "average")
plot(clusters, labels=samplelabels1, cex = 0.3)
```


    
![png](output_16_0.png)
    



```R
#Principal component analysis of cpm filtered
pca.res <- prcomp(t(log2.cpm_MT1.filt.norm), scale.=F, retx=T)
summary(pca.res)
screeplot(pca.res)

pc.var<-pca.res$sdev^2
pc.per<-round(pc.var/sum(pc.var)*100, 1)
pc.per
pca.res.df <- as_tibble(pca.res$x)
```


    Importance of components:
                                PC1      PC2      PC3      PC4      PC5     PC6
    Standard deviation     150.5492 100.1205 79.35500 63.69764 51.48219 45.0181
    Proportion of Variance   0.2941   0.1301  0.08171  0.05265  0.03439  0.0263
    Cumulative Proportion    0.2941   0.4242  0.50588  0.55853  0.59292  0.6192
                                PC7      PC8      PC9     PC10     PC11     PC12
    Standard deviation     39.10811 38.71890 35.01976 30.65201 29.04135 27.70156
    Proportion of Variance  0.01985  0.01945  0.01591  0.01219  0.01094  0.00996
    Cumulative Proportion   0.63907  0.65852  0.67443  0.68663  0.69757  0.70753
                               PC13    PC14    PC15     PC16     PC17     PC18
    Standard deviation     26.51816 25.7482 23.7138 23.16265 22.11783 20.86172
    Proportion of Variance  0.00912  0.0086  0.0073  0.00696  0.00635  0.00565
    Cumulative Proportion   0.71665  0.7252  0.7326  0.73951  0.74586  0.75151
                               PC19     PC20     PC21    PC22     PC23     PC24
    Standard deviation     20.22916 19.89357 19.05705 18.4182 17.88478 17.41418
    Proportion of Variance  0.00531  0.00514  0.00471  0.0044  0.00415  0.00393
    Cumulative Proportion   0.75682  0.76195  0.76667  0.7711  0.77522  0.77915
                               PC25     PC26     PC27     PC28     PC29     PC30
    Standard deviation     16.99069 16.30370 16.00952 15.90953 15.24647 15.03802
    Proportion of Variance  0.00375  0.00345  0.00333  0.00328  0.00302  0.00293
    Cumulative Proportion   0.78290  0.78635  0.78967  0.79296  0.79597  0.79891
                               PC31     PC32     PC33     PC34     PC35     PC36
    Standard deviation     14.70367 14.39188 14.28031 13.91272 13.89925 13.41264
    Proportion of Variance  0.00281  0.00269  0.00265  0.00251  0.00251  0.00233
    Cumulative Proportion   0.80171  0.80440  0.80705  0.80956  0.81207  0.81440
                               PC37     PC38     PC39     PC40     PC41     PC42
    Standard deviation     13.22564 13.19681 13.05771 12.67939 12.46660 12.33895
    Proportion of Variance  0.00227  0.00226  0.00221  0.00209  0.00202  0.00198
    Cumulative Proportion   0.81667  0.81893  0.82114  0.82323  0.82525  0.82722
                               PC43     PC44     PC45     PC46     PC47     PC48
    Standard deviation     12.18750 12.00526 11.86576 11.84264 11.70359 11.59170
    Proportion of Variance  0.00193  0.00187  0.00183  0.00182  0.00178  0.00174
    Cumulative Proportion   0.82915  0.83102  0.83285  0.83467  0.83644  0.83819
                               PC49     PC50    PC51     PC52     PC53     PC54
    Standard deviation     11.49221 11.28694 11.1182 11.04961 10.93834 10.81573
    Proportion of Variance  0.00171  0.00165  0.0016  0.00158  0.00155  0.00152
    Cumulative Proportion   0.83990  0.84155  0.8432  0.84474  0.84629  0.84781
                              PC55     PC56     PC57     PC58     PC59     PC60
    Standard deviation     10.7388 10.64999 10.61754 10.54374 10.47091 10.36641
    Proportion of Variance  0.0015  0.00147  0.00146  0.00144  0.00142  0.00139
    Cumulative Proportion   0.8493  0.85078  0.85224  0.85369  0.85511  0.85650
                               PC61     PC62    PC63    PC64    PC65    PC66
    Standard deviation     10.22175 10.11228 9.93264 9.90403 9.86562 9.85186
    Proportion of Variance  0.00136  0.00133 0.00128 0.00127 0.00126 0.00126
    Cumulative Proportion   0.85786  0.85919 0.86047 0.86174 0.86300 0.86426
                              PC67   PC68    PC69    PC70    PC71    PC72   PC73
    Standard deviation     9.66065 9.6131 9.51887 9.51179 9.45583 9.38076 9.2258
    Proportion of Variance 0.00121 0.0012 0.00118 0.00117 0.00116 0.00114 0.0011
    Cumulative Proportion  0.86547 0.8667 0.86785 0.86902 0.87018 0.87132 0.8724
                              PC74    PC75    PC76    PC77    PC78   PC79    PC80
    Standard deviation     9.15711 9.05285 9.04977 8.97452 8.83127 8.7885 8.70033
    Proportion of Variance 0.00109 0.00106 0.00106 0.00105 0.00101 0.0010 0.00098
    Cumulative Proportion  0.87352 0.87458 0.87564 0.87669 0.87770 0.8787 0.87968
                              PC81    PC82    PC83    PC84    PC85    PC86    PC87
    Standard deviation     8.67945 8.66515 8.58341 8.46364 8.45041 8.41342 8.35146
    Proportion of Variance 0.00098 0.00097 0.00096 0.00093 0.00093 0.00092 0.00091
    Cumulative Proportion  0.88066 0.88163 0.88259 0.88352 0.88445 0.88537 0.88627
                             PC88    PC89    PC90    PC91    PC92    PC93    PC94
    Standard deviation     8.3252 8.30132 8.24330 8.20670 8.18225 8.14990 8.11334
    Proportion of Variance 0.0009 0.00089 0.00088 0.00087 0.00087 0.00086 0.00085
    Cumulative Proportion  0.8872 0.88806 0.88895 0.88982 0.89069 0.89155 0.89240
                              PC95    PC96    PC97    PC98   PC99  PC100   PC101
    Standard deviation     8.02530 7.98156 7.95417 7.94315 7.8704 7.8388 7.81716
    Proportion of Variance 0.00084 0.00083 0.00082 0.00082 0.0008 0.0008 0.00079
    Cumulative Proportion  0.89324 0.89407 0.89489 0.89571 0.8965 0.8973 0.89810
                             PC102   PC103   PC104   PC105   PC106   PC107   PC108
    Standard deviation     7.78652 7.77093 7.74743 7.71374 7.67691 7.62997 7.61840
    Proportion of Variance 0.00079 0.00078 0.00078 0.00077 0.00076 0.00076 0.00075
    Cumulative Proportion  0.89889 0.89967 0.90045 0.90122 0.90199 0.90274 0.90350
                             PC109   PC110   PC111   PC112   PC113   PC114   PC115
    Standard deviation     7.57317 7.55708 7.50929 7.47865 7.46222 7.41666 7.39405
    Proportion of Variance 0.00074 0.00074 0.00073 0.00073 0.00072 0.00071 0.00071
    Cumulative Proportion  0.90424 0.90498 0.90571 0.90644 0.90716 0.90787 0.90858
                            PC116   PC117   PC118   PC119   PC120   PC121   PC122
    Standard deviation     7.3556 7.31044 7.29637 7.28193 7.25536 7.22679 7.18946
    Proportion of Variance 0.0007 0.00069 0.00069 0.00069 0.00068 0.00068 0.00067
    Cumulative Proportion  0.9093 0.90998 0.91067 0.91136 0.91204 0.91272 0.91339
                             PC123   PC124   PC125   PC126   PC127   PC128   PC129
    Standard deviation     7.16959 7.15418 7.10681 7.07086 7.04622 7.03379 6.99436
    Proportion of Variance 0.00067 0.00066 0.00066 0.00065 0.00064 0.00064 0.00063
    Cumulative Proportion  0.91406 0.91472 0.91538 0.91602 0.91667 0.91731 0.91795
                             PC130   PC131   PC132   PC133   PC134   PC135  PC136
    Standard deviation     6.96659 6.94490 6.92689 6.89601 6.88624 6.85068 6.8190
    Proportion of Variance 0.00063 0.00063 0.00062 0.00062 0.00062 0.00061 0.0006
    Cumulative Proportion  0.91858 0.91920 0.91982 0.92044 0.92106 0.92167 0.9223
                            PC137  PC138  PC139   PC140   PC141   PC142   PC143
    Standard deviation     6.8050 6.7875 6.7834 6.76184 6.74339 6.71529 6.70140
    Proportion of Variance 0.0006 0.0006 0.0006 0.00059 0.00059 0.00059 0.00058
    Cumulative Proportion  0.9229 0.9235 0.9241 0.92466 0.92525 0.92583 0.92642
                             PC144   PC145   PC146   PC147   PC148   PC149   PC150
    Standard deviation     6.66969 6.64917 6.63045 6.61731 6.60629 6.57191 6.54643
    Proportion of Variance 0.00058 0.00057 0.00057 0.00057 0.00057 0.00056 0.00056
    Cumulative Proportion  0.92699 0.92757 0.92814 0.92871 0.92927 0.92983 0.93039
                             PC151   PC152   PC153   PC154   PC155   PC156   PC157
    Standard deviation     6.52393 6.51608 6.47598 6.46670 6.45345 6.43432 6.40926
    Proportion of Variance 0.00055 0.00055 0.00054 0.00054 0.00054 0.00054 0.00053
    Cumulative Proportion  0.93094 0.93149 0.93204 0.93258 0.93312 0.93366 0.93419
                             PC158   PC159   PC160   PC161   PC162   PC163   PC164
    Standard deviation     6.39918 6.39647 6.38375 6.34361 6.31308 6.30024 6.27779
    Proportion of Variance 0.00053 0.00053 0.00053 0.00052 0.00052 0.00052 0.00051
    Cumulative Proportion  0.93472 0.93525 0.93578 0.93630 0.93682 0.93733 0.93785
                             PC165  PC166  PC167  PC168  PC169   PC170   PC171
    Standard deviation     6.26873 6.2347 6.2206 6.2045 6.1773 6.16432 6.15092
    Proportion of Variance 0.00051 0.0005 0.0005 0.0005 0.0005 0.00049 0.00049
    Cumulative Proportion  0.93836 0.9389 0.9394 0.9399 0.9404 0.94085 0.94134
                             PC172   PC173   PC174   PC175   PC176   PC177   PC178
    Standard deviation     6.12653 6.11313 6.09875 6.07958 6.04264 6.03611 6.01546
    Proportion of Variance 0.00049 0.00048 0.00048 0.00048 0.00047 0.00047 0.00047
    Cumulative Proportion  0.94183 0.94231 0.94280 0.94327 0.94375 0.94422 0.94469
                             PC179   PC180   PC181   PC182   PC183   PC184   PC185
    Standard deviation     5.99193 5.97390 5.95331 5.91896 5.91182 5.90973 5.87830
    Proportion of Variance 0.00047 0.00046 0.00046 0.00045 0.00045 0.00045 0.00045
    Cumulative Proportion  0.94516 0.94562 0.94608 0.94653 0.94699 0.94744 0.94789
                             PC186   PC187   PC188   PC189   PC190   PC191   PC192
    Standard deviation     5.83640 5.82027 5.80338 5.75428 5.74904 5.72743 5.71494
    Proportion of Variance 0.00044 0.00044 0.00044 0.00043 0.00043 0.00043 0.00042
    Cumulative Proportion  0.94833 0.94877 0.94921 0.94964 0.95007 0.95049 0.95092
                             PC193   PC194   PC195   PC196   PC197  PC198  PC199
    Standard deviation     5.69852 5.67951 5.64744 5.64412 5.59939 5.5745 5.5533
    Proportion of Variance 0.00042 0.00042 0.00041 0.00041 0.00041 0.0004 0.0004
    Cumulative Proportion  0.95134 0.95176 0.95217 0.95258 0.95299 0.9534 0.9538
                            PC200  PC201   PC202   PC203   PC204   PC205   PC206
    Standard deviation     5.5303 5.5237 5.50514 5.47842 5.44922 5.44296 5.43007
    Proportion of Variance 0.0004 0.0004 0.00039 0.00039 0.00039 0.00038 0.00038
    Cumulative Proportion  0.9542 0.9546 0.95498 0.95537 0.95575 0.95614 0.95652
                             PC207   PC208   PC209   PC210   PC211   PC212   PC213
    Standard deviation     5.40625 5.37996 5.36447 5.35306 5.34205 5.31900 5.30615
    Proportion of Variance 0.00038 0.00038 0.00037 0.00037 0.00037 0.00037 0.00037
    Cumulative Proportion  0.95690 0.95728 0.95765 0.95802 0.95839 0.95876 0.95912
                             PC214   PC215   PC216   PC217   PC218   PC219   PC220
    Standard deviation     5.30305 5.29334 5.27626 5.25149 5.23441 5.22839 5.22335
    Proportion of Variance 0.00036 0.00036 0.00036 0.00036 0.00036 0.00035 0.00035
    Cumulative Proportion  0.95949 0.95985 0.96021 0.96057 0.96093 0.96128 0.96164
                             PC221   PC222   PC223   PC224   PC225   PC226   PC227
    Standard deviation     5.21486 5.19135 5.17183 5.16881 5.15092 5.13038 5.11155
    Proportion of Variance 0.00035 0.00035 0.00035 0.00035 0.00034 0.00034 0.00034
    Cumulative Proportion  0.96199 0.96234 0.96269 0.96303 0.96338 0.96372 0.96406
                             PC228   PC229   PC230   PC231   PC232   PC233   PC234
    Standard deviation     5.09624 5.08225 5.07748 5.07406 5.05099 5.02801 5.00652
    Proportion of Variance 0.00034 0.00034 0.00033 0.00033 0.00033 0.00033 0.00033
    Cumulative Proportion  0.96439 0.96473 0.96506 0.96540 0.96573 0.96606 0.96638
                             PC235   PC236   PC237   PC238   PC239   PC240   PC241
    Standard deviation     4.98826 4.97638 4.96789 4.95769 4.93912 4.93493 4.93266
    Proportion of Variance 0.00032 0.00032 0.00032 0.00032 0.00032 0.00032 0.00032
    Cumulative Proportion  0.96671 0.96703 0.96735 0.96767 0.96798 0.96830 0.96861
                             PC242   PC243   PC244   PC245   PC246  PC247  PC248
    Standard deviation     4.90434 4.88881 4.88197 4.86624 4.84988 4.8377 4.8103
    Proportion of Variance 0.00031 0.00031 0.00031 0.00031 0.00031 0.0003 0.0003
    Cumulative Proportion  0.96893 0.96924 0.96955 0.96985 0.97016 0.9705 0.9708
                            PC249  PC250  PC251   PC252   PC253   PC254   PC255
    Standard deviation     4.8037 4.7895 4.7775 4.75338 4.74460 4.72935 4.69841
    Proportion of Variance 0.0003 0.0003 0.0003 0.00029 0.00029 0.00029 0.00029
    Cumulative Proportion  0.9711 0.9714 0.9717 0.97195 0.97224 0.97253 0.97282
                             PC256   PC257   PC258   PC259   PC260   PC261   PC262
    Standard deviation     4.67911 4.66395 4.66259 4.63146 4.63106 4.62038 4.60643
    Proportion of Variance 0.00028 0.00028 0.00028 0.00028 0.00028 0.00028 0.00028
    Cumulative Proportion  0.97310 0.97338 0.97367 0.97394 0.97422 0.97450 0.97477
                             PC263   PC264   PC265   PC266   PC267   PC268   PC269
    Standard deviation     4.58237 4.57183 4.56816 4.55032 4.53543 4.53015 4.50990
    Proportion of Variance 0.00027 0.00027 0.00027 0.00027 0.00027 0.00027 0.00026
    Cumulative Proportion  0.97505 0.97532 0.97559 0.97586 0.97612 0.97639 0.97665
                             PC270   PC271   PC272   PC273   PC274   PC275   PC276
    Standard deviation     4.49780 4.48871 4.47278 4.46749 4.45427 4.44198 4.42657
    Proportion of Variance 0.00026 0.00026 0.00026 0.00026 0.00026 0.00026 0.00025
    Cumulative Proportion  0.97692 0.97718 0.97744 0.97770 0.97795 0.97821 0.97846
                             PC277   PC278   PC279   PC280   PC281   PC282   PC283
    Standard deviation     4.42304 4.39307 4.38941 4.37997 4.36319 4.34779 4.33897
    Proportion of Variance 0.00025 0.00025 0.00025 0.00025 0.00025 0.00025 0.00024
    Cumulative Proportion  0.97872 0.97897 0.97922 0.97947 0.97972 0.97996 0.98020
                             PC284   PC285   PC286   PC287   PC288   PC289   PC290
    Standard deviation     4.31810 4.30405 4.29630 4.28210 4.25896 4.25132 4.22363
    Proportion of Variance 0.00024 0.00024 0.00024 0.00024 0.00024 0.00023 0.00023
    Cumulative Proportion  0.98045 0.98069 0.98093 0.98116 0.98140 0.98163 0.98187
                             PC291   PC292   PC293   PC294   PC295   PC296   PC297
    Standard deviation     4.20659 4.19707 4.18163 4.16556 4.10472 4.09879 4.07298
    Proportion of Variance 0.00023 0.00023 0.00023 0.00023 0.00022 0.00022 0.00022
    Cumulative Proportion  0.98210 0.98232 0.98255 0.98278 0.98299 0.98321 0.98343
                             PC298   PC299   PC300   PC301   PC302   PC303  PC304
    Standard deviation     4.05401 4.05016 4.03512 4.02530 4.00160 3.99756 3.9729
    Proportion of Variance 0.00021 0.00021 0.00021 0.00021 0.00021 0.00021 0.0002
    Cumulative Proportion  0.98364 0.98385 0.98407 0.98428 0.98448 0.98469 0.9849
                            PC305  PC306  PC307  PC308  PC309  PC310  PC311  PC312
    Standard deviation     3.9602 3.9316 3.9279 3.9164 3.9119 3.8986 3.8903 3.8766
    Proportion of Variance 0.0002 0.0002 0.0002 0.0002 0.0002 0.0002 0.0002 0.0002
    Cumulative Proportion  0.9851 0.9853 0.9855 0.9857 0.9859 0.9861 0.9863 0.9865
                             PC313   PC314   PC315   PC316   PC317   PC318   PC319
    Standard deviation     3.87164 3.85544 3.82651 3.81797 3.81244 3.80677 3.79252
    Proportion of Variance 0.00019 0.00019 0.00019 0.00019 0.00019 0.00019 0.00019
    Cumulative Proportion  0.98668 0.98687 0.98706 0.98725 0.98744 0.98763 0.98782
                             PC320   PC321   PC322   PC323   PC324   PC325   PC326
    Standard deviation     3.78356 3.77060 3.75469 3.74951 3.74139 3.72964 3.72023
    Proportion of Variance 0.00019 0.00018 0.00018 0.00018 0.00018 0.00018 0.00018
    Cumulative Proportion  0.98800 0.98819 0.98837 0.98855 0.98873 0.98891 0.98909
                             PC327   PC328   PC329   PC330   PC331   PC332   PC333
    Standard deviation     3.71183 3.69474 3.69059 3.68475 3.66609 3.66162 3.64613
    Proportion of Variance 0.00018 0.00018 0.00018 0.00018 0.00017 0.00017 0.00017
    Cumulative Proportion  0.98927 0.98945 0.98963 0.98980 0.98998 0.99015 0.99032
                             PC334   PC335   PC336   PC337   PC338   PC339   PC340
    Standard deviation     3.63164 3.60017 3.59059 3.57160 3.55820 3.54375 3.52995
    Proportion of Variance 0.00017 0.00017 0.00017 0.00017 0.00016 0.00016 0.00016
    Cumulative Proportion  0.99049 0.99066 0.99083 0.99100 0.99116 0.99132 0.99148
                             PC341   PC342   PC343   PC344   PC345   PC346   PC347
    Standard deviation     3.51308 3.49204 3.48050 3.45168 3.43301 3.41884 3.41172
    Proportion of Variance 0.00016 0.00016 0.00016 0.00015 0.00015 0.00015 0.00015
    Cumulative Proportion  0.99164 0.99180 0.99196 0.99211 0.99227 0.99242 0.99257
                             PC348   PC349   PC350   PC351   PC352   PC353   PC354
    Standard deviation     3.39213 3.37495 3.33680 3.33165 3.32290 3.29259 3.28687
    Proportion of Variance 0.00015 0.00015 0.00014 0.00014 0.00014 0.00014 0.00014
    Cumulative Proportion  0.99272 0.99287 0.99301 0.99316 0.99330 0.99344 0.99358
                             PC355   PC356   PC357   PC358   PC359   PC360   PC361
    Standard deviation     3.26831 3.25203 3.21943 3.19919 3.18922 3.17122 3.15928
    Proportion of Variance 0.00014 0.00014 0.00013 0.00013 0.00013 0.00013 0.00013
    Cumulative Proportion  0.99372 0.99386 0.99399 0.99412 0.99425 0.99439 0.99451
                             PC362   PC363   PC364   PC365   PC366   PC367   PC368
    Standard deviation     3.15357 3.12353 3.11914 3.08392 3.06817 3.03798 3.01677
    Proportion of Variance 0.00013 0.00013 0.00013 0.00012 0.00012 0.00012 0.00012
    Cumulative Proportion  0.99464 0.99477 0.99490 0.99502 0.99514 0.99526 0.99538
                             PC369   PC370   PC371   PC372   PC373   PC374   PC375
    Standard deviation     2.98893 2.98319 2.95972 2.93633 2.92843 2.91251 2.88937
    Proportion of Variance 0.00012 0.00012 0.00011 0.00011 0.00011 0.00011 0.00011
    Cumulative Proportion  0.99550 0.99561 0.99573 0.99584 0.99595 0.99606 0.99617
                             PC376   PC377   PC378   PC379  PC380  PC381  PC382
    Standard deviation     2.87980 2.86882 2.86122 2.85016 2.8374 2.8286 2.8228
    Proportion of Variance 0.00011 0.00011 0.00011 0.00011 0.0001 0.0001 0.0001
    Cumulative Proportion  0.99627 0.99638 0.99649 0.99659 0.9967 0.9968 0.9969
                            PC383  PC384  PC385  PC386  PC387  PC388  PC389  PC390
    Standard deviation     2.8189 2.8033 2.7909 2.7865 2.7709 2.7627 2.7506 2.7418
    Proportion of Variance 0.0001 0.0001 0.0001 0.0001 0.0001 0.0001 0.0001 0.0001
    Cumulative Proportion  0.9970 0.9971 0.9972 0.9973 0.9974 0.9975 0.9976 0.9977
                            PC391  PC392  PC393   PC394   PC395   PC396   PC397
    Standard deviation     2.7268 2.7175 2.7069 2.69413 2.68665 2.68108 2.67023
    Proportion of Variance 0.0001 0.0001 0.0001 0.00009 0.00009 0.00009 0.00009
    Cumulative Proportion  0.9978 0.9979 0.9980 0.99809 0.99818 0.99827 0.99837
                             PC398   PC399   PC400   PC401   PC402   PC403   PC404
    Standard deviation     2.66422 2.65428 2.65026 2.64307 2.63880 2.61911 2.58518
    Proportion of Variance 0.00009 0.00009 0.00009 0.00009 0.00009 0.00009 0.00009
    Cumulative Proportion  0.99846 0.99855 0.99864 0.99873 0.99882 0.99891 0.99900
                             PC405   PC406   PC407   PC408   PC409   PC410   PC411
    Standard deviation     2.57411 2.53380 2.52563 2.50250 2.49494 2.43743 2.42349
    Proportion of Variance 0.00009 0.00008 0.00008 0.00008 0.00008 0.00008 0.00008
    Cumulative Proportion  0.99908 0.99917 0.99925 0.99933 0.99941 0.99949 0.99957
                             PC412   PC413   PC414   PC415   PC416   PC417
    Standard deviation     2.40647 2.39920 2.37844 2.36609 2.33262 2.29016
    Proportion of Variance 0.00008 0.00007 0.00007 0.00007 0.00007 0.00007
    Cumulative Proportion  0.99964 0.99972 0.99979 0.99986 0.99993 1.00000
                               PC418
    Standard deviation     3.553e-14
    Proportion of Variance 0.000e+00
    Cumulative Proportion  1.000e+00



<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>29.4</li><li>13</li><li>8.2</li><li>5.3</li><li>3.4</li><li>2.6</li><li>2</li><li>1.9</li><li>1.6</li><li>1.2</li><li>1.1</li><li>1</li><li>0.9</li><li>0.9</li><li>0.7</li><li>0.7</li><li>0.6</li><li>0.6</li><li>0.5</li><li>0.5</li><li>0.5</li><li>0.4</li><li>0.4</li><li>0.4</li><li>0.4</li><li>0.3</li><li>0.3</li><li>0.3</li><li>0.3</li><li>0.3</li><li>0.3</li><li>0.3</li><li>0.3</li><li>0.3</li><li>0.3</li><li>0.2</li><li>0.2</li><li>0.2</li><li>0.2</li><li>0.2</li><li>0.2</li><li>0.2</li><li>0.2</li><li>0.2</li><li>0.2</li><li>0.2</li><li>0.2</li><li>0.2</li><li>0.2</li><li>0.2</li><li>0.2</li><li>0.2</li><li>0.2</li><li>0.2</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0.1</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>⋯</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li></ol>




    
![png](output_17_2.png)
    



```R
ggplot(pca.res.df) +
  aes(x=PC1, y=PC2, color=groupMT1) +
  geom_point(size=2) +
  xlab(paste0("PC1 (",pc.per[1],"%",")")) + 
  ylab(paste0("PC2 (",pc.per[2],"%",")")) +
  labs(title="PCA plot",
       caption=paste0("produced on ", Sys.time())) +
  coord_fixed() +
  theme_classic()
```


    
![png](output_18_0.png)
    



```R
ggplot(pca.res.df) +
  aes(x = PC1, y = PC2, color = groupMT1, label = samplelabels1) +
  geom_point(size = 2) +
  geom_text(vjust = -0.5, size = 3) +  # Add labels
  xlab(paste0("PC1 (", pc.per[1], "%", ")")) +
  ylab(paste0("PC2 (", pc.per[2], "%", ")")) +
  labs(title = "PCA plot",
       caption = paste0("produced on ", Sys.time())) +
  coord_fixed() +
  theme_classic()
```


    
![png](output_19_0.png)
    



```R
library(ggrepel)

ggplot(pca.res.df) +
  aes(x = PC1, y = PC2, color = groupMT1, label = samplelabels1) +
  geom_text_repel(size = 3) +  # only labels, no points
  xlab(paste0("PC1 (", pc.per[1], "%", ")")) +
  ylab(paste0("PC2 (", pc.per[2], "%", ")")) +
  labs(title = "PCA plot",
       caption = paste0("produced on ", Sys.time())) +
  coord_fixed() +
  theme_classic()
```

    Warning message:
    "ggrepel: 403 unlabeled data points (too many overlaps). Consider increasing max.overlaps"



    
![png](output_20_1.png)
    



```R
# Create a new label column with only the part before the first underscore
short_label <- sub("_.*", "", samplelabels1)
```


```R
labelcheck <- ggplot(pca.res.df) +
  aes(x = PC1, y = PC2, color = groupMT1, label = short_label) +
  geom_point(size = 1) +
  geom_text(vjust = -0.5, size = 2) +  # Add labels
  xlab(paste0("PC1 (", pc.per[1], "%", ")")) +
  ylab(paste0("PC2 (", pc.per[2], "%", ")")) +
  labs(title = "PCA plot",
       caption = paste0("produced on ", Sys.time())) +
  coord_fixed() +
  theme_classic()
labelcheck
```


    
![png](output_22_0.png)
    



```R
ggsave("/staging/leuven/stg_00134/Margaux/Revision/BatchCorrection/PCAlabels.pdf", plot = labelcheck, width = 20, height = 20)
```


```R
ggplot(pca.res.df) +
  aes(x = PC1, y = PC2, color = groupMT1, label = short_label) +
  geom_text_repel(size = 1,  max.overlaps = Inf) +  # only labels, no points
  xlab(paste0("PC1 (", pc.per[1], "%", ")")) +
  ylab(paste0("PC2 (", pc.per[2], "%", ")")) +
  labs(title = "PCA plot",
       caption = paste0("produced on ", Sys.time())) +
  coord_fixed() +
  theme_classic()
```


    
![png](output_24_0.png)
    



```R
pdf("/staging/leuven/stg_00134/Margaux/3DsourcePCA.pdf", height=30, width=20)
ggplot(pca.res.df) +
  aes(x=PC1, y=PC2, color=groupMT1) +
  geom_point(size=2) +
  xlab(paste0("PC1 (",pc.per[1],"%",")")) + 
  ylab(paste0("PC2 (",pc.per[2],"%",")")) +
  labs(title="PCA plot",
       caption=paste0("produced on ", Sys.time())) +
  coord_fixed() +
 theme_classic()
dev.off()
```


<strong>png:</strong> 2



```R
#pdf("/staging/leuven/stg_00134/Margaux/3DsourcePCA.pdf", height=30, width=20)
#ggplot(pca.res.df) +
#  aes(x=PC1, y=PC2, color=groupMT1) +
#  geom_point(size=2) +
  xlab(paste0("PC1 (",pc.per[1],"%",")")) + 
  ylab(paste0("PC2 (",pc.per[2],"%",")")) +
  labs(title="PCA plot",
       caption=paste0("produced on ", Sys.time())) +
  coord_fixed() +
  theme_bw()
#dev.off()
```


    Error in xlab(paste0("PC1 (", pc.per[1], "%", ")")) + ylab(paste0("PC2 (", : non-numeric argument to binary operator
    Traceback:



# myogenic gene based PCA


```R
MT1 <- rownames_to_column(MT1,var="Gene_ID")
MT1
```


```R
myo <- MT1 %>%filter(Gene_ID %in% c("ABLIM1","ACHE","ACSL1","ACTA1","ACTC1","ACTN2","ACTN3","ADAM12","ADCY9","AEBP1","AGL","AGRN","AK1","AKT2","ANKRD2","APLNR","APOD","APP","ATP2A1","ATP6AP1","BAG1","BDKRB2","BHLHE40","BIN1","CACNA1H","CACNG1","CAMK2B","CASQ1","CASQ2","CAV3","CD36","CDH13","CDKN1A","CFD","CHRNA1","CHRNB1","CHRNG","CKB","CKM","CKMT2","CLU","CNN3","COL15A1","COL1A1","COL3A1","COL4A2","COL6A2","COL6A3","COX6A2","COX7A1","CRAT","CRYAB","CSRP3","CTF1","DAPK2","DES","DMD","DMPK","DTNA","EFS","EIF4A2","ENO3","EPHB3","ERBB3","FABP3","FDPS","FGF2","FHL1","FKBP1B","FLII","FOXO4","FST","FXYD1","GAA","GABARAPL2","GADD45B","GJA5","GNAO1","GPX3","GSN","HBEGF","HDAC5","HRC","HSPB2","HSPB8","IFRD1","IGF1","IGFBP3","IGFBP7","ITGA7","ITGB1","ITGB4","ITGB5","KCNH1","KCNH2","KIFC3","KLF5","LAMA2","LARGE1","LDB3","LPIN1","LSP1","MAPK12","MAPRE3","MB","MEF2A","MEF2C","MEF2D","MRAS","MYBPC3","MYBPH","MYF6","MYH1","MYH11","MYH2","MYH3","MYH4","MYH7","MYH8","MYH9","MYL1","MYL2","MYL3","MYL4","MYL6B","MYL7","MYLK","MYL11","MYO1C","MYOG","MYOM1","MYOM2","MYOZ1","NAV2","NCAM1","NOS1","NOTCH1","NQO1","OCEL1","PC","PDE4DIP","PDLIM7","PFKM","PICK1","PKIA","PLXNB2","PPFIA4","PPP1R3C","PRNP","PSEN2","PTGIS","PTP4A3","PVALB","PYGM","RB1","REEP1","RIT1","RYR1","SCD","SCHIP1","SGCA","SGCD","SGCG","SH2B1","SH3BGR","SIRT2","SLC6A8","SLN","SMTN","SOD3","SORBS1","SORBS3","SPARC","SPDEF","SPEG","SPHK1","SPTAN1","SSPN","DENND2B","STC2","SVIL","SYNGR2","TAGLN","TCAP","TEAD4","TGFB1","TNNC1","TNNC2","TNNI1","TNNI2","TNNT1","TNNT2","TNNT3","TPD52L1","TPM2","TPM3","TSC2","VIPR1","WWTR1","NEO1", "TCF3", "MAPK14", "CTNNA2", "MEF2B", "CDH15", "MYF5", "ABL1", "BNIP2", "CDH2", "CDH4", "TCF12", "CTNNA1", "SPAG9", "NTN3", "BOC", "TCF4", "CDON", "CTNNB1", "CDC42", "MYOD1", "MAP2K6", "MAPK11"))
myo
```


```R
myo.m <- column_to_rownames(myo, var="Gene_ID")
myo.m <- as.matrix(myo.m)
myo.m
```


```R
DGE_myo <- DGEList(myo.m)
cpmMYO <- cpm(DGE_myo)
log2.MYOCPM <- cpm(DGE_myo, log=TRUE)
table(rowSums(DGE_myo$counts==0)==418)
```


```R
log2.MYOCPM <- cpm(DGE_myo, log=TRUE)
DGE_myo.filt.norm <- calcNormFactors(DGE_myo, method="TMM")
log2.cpm_myo.filt.norm <- cpm(DGE_myo.filt.norm, log=TRUE)
```


```R
samplelabelsmyo <- colnames(log2.cpm_myo.filt.norm)
```


```R
#hierarchical clustering: distance matrix 
distance <- dist(t(log2.cpm_myo.filt.norm), method = "euclidean") 
clusters <- hclust(distance, method = "average")
plot(clusters, labels=samplelabelsmyo, cex = 0.2)
```


```R
#Principal component analysis of cpm filtered
pca.res <- prcomp(t(log2.cpm_myo.filt.norm), scale.=F, retx=T)
summary(pca.res)
screeplot(pca.res)

pc.var<-pca.res$sdev^2
pc.per<-round(pc.var/sum(pc.var)*100, 1)
pc.per
pca.res.df <- as_tibble(pca.res$x)
```


```R
myo3 <- ggplot(pca.res.df) +
  aes(x=PC1, y=PC3, color=groupMT1) +
  geom_point(size=1) +
  xlab(paste0("PC1 (",pc.per[1],"%",")")) + 
  ylab(paste0("PC3 (",pc.per[3],"%",")")) +
  labs(title="PCA plot",
       caption=paste0("produced on ", Sys.time())) +
  coord_fixed() +
  theme_classic()
```


```R
short_labelmyo <- sub("_.*", "", samplelabelsmyo)
```


```R
labelcheck <- ggplot(pca.res.df) +
  aes(x = PC1, y = PC2, color = groupMT1, label = short_labelmyo) +
  geom_point(size = 1) +
  geom_text(vjust = -0.5, size = 2) +  # Add labels
  xlab(paste0("PC1 (", pc.per[1], "%", ")")) +
  ylab(paste0("PC2 (", pc.per[2], "%", ")")) +
  labs(title = "PCA plot",
       caption = paste0("produced on ", Sys.time())) +
  coord_fixed() +
  theme_classic()
labelcheck
```


```R
ggsave("/staging/leuven/stg_00134/Margaux/Revision/BatchCorrection/PCAlabelsmyo.pdf", plot = labelcheck, width = 20, height = 20)
```


```R
myo3
```


```R
library(stringr)  # for str_extract

# Extract the prefix (e.g., "1D", "13A", etc.) into a new column
prefix <- str_extract(samplelabels1, "^[0-9]+[A-Z]")
```


```R
prefix
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>'1D'</li><li>'1D'</li><li>'1D'</li><li>'1D'</li><li>'9D'</li><li>'9D'</li><li>'9D'</li><li>'9D'</li><li>'10D'</li><li>'10D'</li><li>'12D'</li><li>'12D'</li><li>'12D'</li><li>'12D'</li><li>'13D'</li><li>'13D'</li><li>'13D'</li><li>'13D'</li><li>'13D'</li><li>'17D'</li><li>'17D'</li><li>'17D'</li><li>'17D'</li><li>'17D'</li><li>'17D'</li><li>'17D'</li><li>'17D'</li><li>'17D'</li><li>'17D'</li><li>'17D'</li><li>'17D'</li><li>'15D'</li><li>'15D'</li><li>'15D'</li><li>'6D'</li><li>'6D'</li><li>'6D'</li><li>'6D'</li><li>'6D'</li><li>'6D'</li><li>'12D'</li><li>'12D'</li><li>'12D'</li><li>'12D'</li><li>'12D'</li><li>'1D'</li><li>'1D'</li><li>'1D'</li><li>'1D'</li><li>'6D'</li><li>'6D'</li><li>'6D'</li><li>'6D'</li><li>'6D'</li><li>'6D'</li><li>'9D'</li><li>'9D'</li><li>'9D'</li><li>'9D'</li><li>'10D'</li><li>'10D'</li><li>'20T'</li><li>'20T'</li><li>'20T'</li><li>'21T'</li><li>'21T'</li><li>'21T'</li><li>'23T'</li><li>'23T'</li><li>'23T'</li><li>'23T'</li><li>'23T'</li><li>'23T'</li><li>'22T'</li><li>'22T'</li><li>'22T'</li><li>'23T'</li><li>'23T'</li><li>'23T'</li><li>'23T'</li><li>'23T'</li><li>'23T'</li><li>'26T'</li><li>'26T'</li><li>'26T'</li><li>'27T'</li><li>'27T'</li><li>'27T'</li><li>'23T'</li><li>'23T'</li><li>'23T'</li><li>'23T'</li><li>'23T'</li><li>'24T'</li><li>'24T'</li><li>'24T'</li><li>'25T'</li><li>'25T'</li><li>'25T'</li><li>'25T'</li><li>'27T'</li><li>'27T'</li><li>'27T'</li><li>'13E'</li><li>'13E'</li><li>'13E'</li><li>'10F'</li><li>'10F'</li><li>'10F'</li><li>'10F'</li><li>'13F'</li><li>'13F'</li><li>'13F'</li><li>'33A'</li><li>'33A'</li><li>'33A'</li><li>'33A'</li><li>'33A'</li><li>'33A'</li><li>'33A'</li><li>'33A'</li><li>'33A'</li><li>'33A'</li><li>'33A'</li><li>'33A'</li><li>'33A'</li><li>'33A'</li><li>'33A'</li><li>'33A'</li><li>'33A'</li><li>'33A'</li><li>'33A'</li><li>'33A'</li><li>'33A'</li><li>'33A'</li><li>'33A'</li><li>'33A'</li><li>'13A'</li><li>'13A'</li><li>'13A'</li><li>'20A'</li><li>'20A'</li><li>'20A'</li><li>'20A'</li><li>'46A'</li><li>'46A'</li><li>'46A'</li><li>'47A'</li><li>'47A'</li><li>'49A'</li><li>'49A'</li><li>'49A'</li><li>'49A'</li><li>'49A'</li><li>'49A'</li><li>'49A'</li><li>'49A'</li><li>'50A'</li><li>'50A'</li><li>'52A'</li><li>'52A'</li><li>'52A'</li><li>'52A'</li><li>'52A'</li><li>'52A'</li><li>'52A'</li><li>'52A'</li><li>'52A'</li><li>'52A'</li><li>'54A'</li><li>'54A'</li><li>'60A'</li><li>'60A'</li><li>'43C'</li><li>'43C'</li><li>'39C'</li><li>'39C'</li><li>'39C'</li><li>'41C'</li><li>'41C'</li><li>'45C'</li><li>'45C'</li><li>'45C'</li><li>'45C'</li><li>'45C'</li><li>'45C'</li><li>'45C'</li><li>'45C'</li><li>'45C'</li><li>'45C'</li><li>'45C'</li><li>'45C'</li><li>'45C'</li><li>'45C'</li><li>'45C'</li><li>'45C'</li><li>'45C'</li><li>'45C'</li><li>'45C'</li><li>'45C'</li><li>⋯</li><li>'45C'</li><li>'45C'</li><li>'45C'</li><li>'45C'</li><li>'45C'</li><li>'45C'</li><li>'45C'</li><li>'53C'</li><li>'53C'</li><li>'24A'</li><li>'24A'</li><li>'24A'</li><li>'55C'</li><li>'55C'</li><li>'55C'</li><li>'58C'</li><li>'58C'</li><li>'58C'</li><li>'47A'</li><li>'47A'</li><li>'40C'</li><li>'40C'</li><li>'1D'</li><li>'1D'</li><li>'1D'</li><li>'1D'</li><li>'6D'</li><li>'6D'</li><li>'6D'</li><li>'6D'</li><li>'6D'</li><li>'6D'</li><li>'12D'</li><li>'12D'</li><li>'12D'</li><li>'12D'</li><li>'12D'</li><li>'12D'</li><li>'20T'</li><li>'20T'</li><li>'20T'</li><li>'21T'</li><li>'21T'</li><li>'21T'</li><li>'23T'</li><li>'23T'</li><li>'23T'</li><li>'23T'</li><li>'23T'</li><li>'24T'</li><li>'24T'</li><li>'24T'</li><li>'25T'</li><li>'25T'</li><li>'27T'</li><li>'27T'</li><li>'27T'</li><li>'27T'</li><li>'27T'</li><li>'27T'</li><li>'34A'</li><li>'34A'</li><li>'34A'</li><li>'34A'</li><li>'34A'</li><li>'34A'</li><li>'34A'</li><li>'34A'</li><li>'34A'</li><li>'34A'</li><li>'34A'</li><li>'34A'</li><li>'34A'</li><li>'34A'</li><li>'34A'</li><li>'34A'</li><li>'34A'</li><li>'34A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'61A'</li><li>'62F'</li><li>'62F'</li><li>'62F'</li><li>'62F'</li><li>'62F'</li><li>'62F'</li><li>'62F'</li><li>'62F'</li><li>'62F'</li><li>'62F'</li><li>'62F'</li><li>'62F'</li><li>'62F'</li><li>'62F'</li><li>'62F'</li><li>'62F'</li><li>'62F'</li><li>'62F'</li><li>'62F'</li><li>'62F'</li><li>'62F'</li><li>'62F'</li><li>'62F'</li><li>'62F'</li><li>'62F'</li><li>'62F'</li><li>'62F'</li><li>'62F'</li><li>'62F'</li><li>'62F'</li><li>'62F'</li><li>'62F'</li><li>'62F'</li><li>'62F'</li><li>'62F'</li><li>NA</li><li>NA</li><li>NA</li><li>NA</li><li>NA</li><li>NA</li><li>NA</li></ol>




```R
ggplot(pca.res.df) +
  aes(x = PC1, y = PC2, color = prefix) +
  geom_point(size = 2) +
  xlab(paste0("PC1 (", pc.per[1], "%)")) + 
  ylab(paste0("PC2 (", pc.per[2], "%)")) +
  labs(title = "PCA plot",
       caption = paste0("produced on ", Sys.time())) +
  coord_fixed() +
  theme_classic()
```


    
![png](output_43_0.png)
    



```R
library(RColorBrewer)

# Get as many distinct colors as needed
my_colors <- colorRampPalette(brewer.pal(12, "Set3"))(length(unique(prefix)))
my_colors2 <- colorRampPalette(brewer.pal(11, "BrBG"))(length(unique(prefix)))
```


```R
my_colors
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>'#8DD3C7'</li><li>'#ABDEC1'</li><li>'#CAEABC'</li><li>'#E8F6B6'</li><li>'#FAF9B5'</li><li>'#E8E7C0'</li><li>'#D7D4CA'</li><li>'#C5C2D5'</li><li>'#C6B1CA'</li><li>'#D7A1AE'</li><li>'#E79292'</li><li>'#F88277'</li><li>'#DF8A87'</li><li>'#BE97A1'</li><li>'#9DA5BB'</li><li>'#83B1D0'</li><li>'#A4B1B1'</li><li>'#C6B293'</li><li>'#E7B375'</li><li>'#F5B862'</li><li>'#E1C364'</li><li>'#CECE66'</li><li>'#BAD968'</li><li>'#BFDB7E'</li><li>'#D3D69F'</li><li>'#E6D1C0'</li><li>'#FACDE1'</li><li>'#F3CFE2'</li><li>'#EAD3DE'</li><li>'#E0D6DB'</li><li>'#D7D4D7'</li><li>'#CFBCD0'</li><li>'#C8A4C8'</li><li>'#C08DC1'</li><li>'#BD8DBD'</li><li>'#C2A9C0'</li><li>'#C6C6C2'</li><li>'#CAE3C4'</li><li>'#D5EBB4'</li><li>'#E3EB9D'</li><li>'#F1EC86'</li><li>'#FFED6F'</li></ol>




```R
my_colors2
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>'#543005'</li><li>'#613806'</li><li>'#6F4007'</li><li>'#7C4808'</li><li>'#8A5009'</li><li>'#975B11'</li><li>'#A3671A'</li><li>'#B07222'</li><li>'#BC7E2B'</li><li>'#C58D3C'</li><li>'#CD9D50'</li><li>'#D4AD63'</li><li>'#DCBD77'</li><li>'#E2C888'</li><li>'#E8D19A'</li><li>'#EEDBAB'</li><li>'#F3E4BC'</li><li>'#F5E9CA'</li><li>'#F5EDD6'</li><li>'#F5F0E2'</li><li>'#F5F3EE'</li><li>'#EFF3F3'</li><li>'#E4F0EF'</li><li>'#D8EEEB'</li><li>'#CDEBE7'</li><li>'#C0E7E1'</li><li>'#AEE0D8'</li><li>'#9DD9CF'</li><li>'#8CD1C7'</li><li>'#7AC9BD'</li><li>'#68BBB1'</li><li>'#55AEA4'</li><li>'#43A198'</li><li>'#32948C'</li><li>'#258880'</li><li>'#197C74'</li><li>'#0C7068'</li><li>'#00645C'</li><li>'#005A51'</li><li>'#005046'</li><li>'#00463B'</li><li>'#003C30'</li></ol>




```R
Label_labs <- ggplot(pca.res.df) +
  aes(x = PC1, y = PC2, color = prefix, label = prefix) +
  geom_point(size = 2) +
  geom_text(vjust = -0.5, size = 3) +
  scale_color_manual(values = my_colors) +
  xlab(paste0("PC1 (", pc.per[1], "%)")) + 
  ylab(paste0("PC2 (", pc.per[2], "%)")) +
  labs(title = "PCA plot",
       caption = paste0("produced on ", Sys.time())) +
  coord_fixed() +
  theme_classic()
```


```R
ggplot(pca.res.df) +
  aes(x = PC1, y = PC2, color = prefix, label = prefix) +
  geom_point(size = 2) +
  geom_text(vjust = -0.5, size = 3) +
  scale_color_manual(values = my_colors2) +
  xlab(paste0("PC1 (", pc.per[1], "%)")) + 
  ylab(paste0("PC2 (", pc.per[2], "%)")) +
  labs(title = "PCA plot",
       caption = paste0("produced on ", Sys.time())) +
  coord_fixed() +
  theme_classic()
```

    Warning message:
    "[1m[22mRemoved 7 rows containing missing values or values outside the scale range
    (`geom_text()`)."



    
![png](output_48_1.png)
    



```R
Dots_lab3 <- ggplot(pca.res.df) +
  aes(x = PC1, y = PC2, color = prefix) +
  geom_point(size = 3) +
  scale_color_manual(values = my_colors) +
  xlab(paste0("PC1 (", pc.per[1], "%)")) + 
  ylab(paste0("PC2 (", pc.per[2], "%)")) +
  labs(title = "PCA plot",
       caption = paste0("produced on ", Sys.time())) +
  coord_fixed() +
  theme_classic()
```


```R
Dots_lab2 <- ggplot(pca.res.df) +
  aes(x = PC1, y = PC2, color = prefix) +
  geom_point(size = 2) +
  scale_color_manual(values = my_colors) +
  xlab(paste0("PC1 (", pc.per[1], "%)")) + 
  ylab(paste0("PC2 (", pc.per[2], "%)")) +
  labs(title = "PCA plot",
       caption = paste0("produced on ", Sys.time())) +
  coord_fixed() +
  theme_classic()
```


```R
ggsave("/staging/leuven/stg_00134/Margaux/Revision/BatchCorrection/Dots_lab2.pdf", plot = Dots_lab2, width = 30, height = 20)
ggsave("/staging/leuven/stg_00134/Margaux/Revision/BatchCorrection/Dots_lab3.pdf", plot = Dots_lab3, width = 30, height = 20)
ggsave("/staging/leuven/stg_00134/Margaux/Revision/BatchCorrection/Label_labs.pdf", plot = Label_labs, width = 30, height = 20)
```

    Warning message:
    "[1m[22mRemoved 7 rows containing missing values or values outside the scale range
    (`geom_text()`)."



```R

```
